import { ADVANCED_DIMENSIONS, deepClone, detectDatasetShape, extractRecordArray, adaptRecord, canonicalRecord, compatibilityProjection, projectionLosses, parseAdvancedDocument, stageAdvancedTransaction, stageRecordReplacement, validateCanonicalLinks as validateCoreLinks, validateRelationships, controlledValueFinding, haversineKm } from './scribe-core.mjs';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)],copy=deepClone;
const REGISTRY_NAMES=['types','tags','functions','relationship-types','review-states','location-types','location-access','location-precision','chronology-qualifiers','chronology-precision','phase-types','evidence-forms','conditions','investigation-types','workflow-enrichment-states','workflow-enrichment-reasons'];
const registry={},status={},arrayFields=['alternateNames','cultures','politicalEntities'];
const demo=[{id:'AM-0001',name:'Göbekli Tepe',latitude:37.2231,longitude:38.9226,canonicalType:'Religious Site',tags:['construction:megalithic','religion:ritual','religion:temple-complex'],cultures:['Pre-Pottery Neolithic'],politicalEntities:[],functions:['ritual','ceremonial'],alternateNames:[],phases:[],chronology:[],relationships:[],periodStart:-9600,periodEnd:-8200,reliability:'high',description:'Neolithic archaeological site in Upper Mesopotamia.',sources:['https://whc.unesco.org/'],notes:'',needsResearch:false,coordinateAccess:'public',coordinatePrecision:'exact'}];
let sourceRecords=copy(demo),records=copy(demo),original=copy(demo),exportedCheckpoint=copy(demo),selected=0,history=[],future=[],filename='scribe-demo.json',datasetShape='scribe',reviewStates={},taxSelections={type:[],tags:[],functions:[]},mapZoom=16,renderedSources='',renderedPhases='[]',renderedChronology='[]',renderedComponents='[]',renderedRelationships='[]',renderedEvidence='[]',renderedConditions='[]',renderedInvestigations='[]',windowsLocked=false,fixtureManifest=null,fixtureId='',mode='catalogue',previewMode='canonical',advancedDimension='names',unescoProposals={},proposalDecisions={},newSiteProposals={},newSiteStatus={},researchProposals={},researchDecisions={},reviewCandidates={},componentCandidates={},phaseCandidates={};

// v0.7.0: "stage shell" state. The app's ~6 distinct jobs (Home / Enrichment / New Sites /
// Scraping / Curator / Editor) each show only the windows relevant to that job instead of all
// windows always on screen — see the stage-nav tabs in the header and every .window's
// data-stage attribute in index.html. None of this changes what a governed mutation is or how
// it is staged; it only changes which windows are visible and how they are laid out.
const STAGES=['home','enrichment','newsites','scraping','curator','editor'];
const STAGE_META=[{id:'home',icon:'🏠',label:'Home'},{id:'enrichment',icon:'✎',label:'Enrichment'},{id:'newsites',icon:'📍',label:'New Sites'},{id:'scraping',icon:'🔎',label:'Scraping'},{id:'curator',icon:'🔗',label:'Curator'},{id:'editor',icon:'🧰',label:'Editor'}];
const CURATOR_RADIUS_KM=10,NEARBY_RADIUS_KM=25;
let currentStage='home',focusCoords=null,bulkSelected=new Set(),scrapeChips=new Set(),curatorTab='pending';
// v0.7.1: Curator compare split-pane (feature 2) state — compareState holds the two named
// centers (existing record / candidate) the Coordinate Inspector renders side by side while
// compareMode is on; both panes share the single mapZoom state (documented simplification,
// see IMPLEMENTATION_NOTES_v0.7.1.md) rather than tracking two independent zoom levels.
let compareMode=false,compareState=null;
// v0.7.2: chronological navigator + sort (feature 1). CHRONO_FLOOR/CHRONO_CEIL are exactly the
// working range Jaimy stated (20000 BC → 1950) and are the dual-thumb slider's whole domain; the
// two outlier toggles below FORCE-INCLUDE records that fall outside it (they add records back,
// they never narrow further). chronoActive stays false until the range is actually touched, so
// anyone who ignores this control sees no behaviour change at all — and even once it is active,
// a record with no periodStart is never hidden by it (546 of the real 2,103 records are undated;
// silently dropping them would contradict this app's "never silently hide real data" rule, so
// they always show and #chrono-note states the count out loud).
const CHRONO_FLOOR=-20000,CHRONO_CEIL=1950;
let chronoMin=CHRONO_FLOOR,chronoMax=CHRONO_CEIL,chronoActive=false,chronoBefore=false,chronoAfter=false,chronoDragWhich=null,recordSort='catalogue';
// v0.7.2: EDIT COORDINATES (feature 2). coordEdit gates every coordinate-moving interaction on
// the Coordinate Inspector; coordPending is the not-yet-staged position the draggable marker is
// showing. Nothing reaches records[] until SAVE, which goes through commit() →
// stageRecordReplacement() like every other field edit.
let coordEdit=false,coordPending=null,coordDragging=false;

async function loadAssets(){await Promise.all(REGISTRY_NAMES.map(async n=>{const j=await fetch(`data/registries/${n}.json`).then(r=>r.json());registry[n]=j.entries||[];status[n]=new Map(registry[n].map(e=>[e.id,e.status||'active']))}));fixtureManifest=await fetch('data/fixtures.json').then(r=>r.json())}
const entries=n=>registry[n]||[],list=v=>v.split(';').map(x=>x.trim()).filter(Boolean),num=v=>v===''?'':Number(v);
function normalize(json){const a=extractRecordArray(json);datasetShape=detectDatasetShape(a);sourceRecords=copy(a);return a.map((r,i)=>adaptRecord(r,i,datasetShape))}
function canonical(r){return canonicalRecord(r)}
const isChanged=i=>JSON.stringify(records[i])!==JSON.stringify(original[i]),hasUnexported=()=>JSON.stringify(records)!==JSON.stringify(exportedCheckpoint);
function projection(r,i){return compatibilityProjection(sourceRecords[i],r,isChanged(i))}
function losses(r,i){return projectionLosses(r,isChanged(i))}
function lossReport(){const rows=records.map((r,i)=>{const items=losses(r,i).filter(x=>x[0]!=='none').map(([severity,field,message])=>({severity,field,message}));if(r.workflow?.pendingRemoval)items.push({severity:'warning',field:'workflow.pendingRemoval',message:`Excluded from this export — marked for removal ${r.workflow.pendingRemoval.at}. Restore in Editor to include it again.`});return{id:r.id,name:r.name,losses:items}}).filter(x=>x.losses.length);return{generatedAt:new Date().toISOString(),sourceFile:filename,mode,summary:{records:records.length,changed:records.filter((_,i)=>isChanged(i)).length,notices:rows.reduce((n,x)=>n+x.losses.length,0)},records:rows}}

async function fixture(id=fixtureManifest.fixtures[0].id){mode='fixture';fixtureId=id;const f=fixtureManifest.fixtures.find(x=>x.id===id),ids=new Set(f.recordIds);if(id==='F10')ids.add('SYN-S01');if(id==='F02')ids.add('SYN-S02');if(id==='F12'){ids.add('SYN-S03-A');ids.add('SYN-S03-B')}datasetShape='archeomaps';records=normalize(fixtureManifest.records.filter(r=>ids.has(r.id)));original=copy(records);exportedCheckpoint=copy(records);filename=`fixture-${id}.json`;selected=0;history=[];future=[];reviewStates={};$('#fixture-picker-wrap').classList.remove('hidden');$('#fixture-picker').value=id;$('#fixture-mode').innerHTML='🧪 <span class="mode-lamp">FIXTURE MODE</span>';render();toast(`Loaded ${id}: ${f.label}`)}
function importFile(file){if(hasUnexported()&&!confirm('Leave current unexported changes behind?'))return;const fr=new FileReader();fr.onload=()=>{try{mode='catalogue';fixtureId='';records=normalize(JSON.parse(fr.result));original=copy(records);exportedCheckpoint=copy(records);filename=file.name;selected=0;history=[];future=[];reviewStates={};$('#fixture-picker-wrap').classList.add('hidden');$('#fixture-mode').textContent='🧪 FIXTURE MODE';saveLocal();render();toast(`Opened ${records.length} records without changing the source`)}catch(e){toast(e.message)}};fr.readAsText(file)}

// v0.7.2 (bug 2): "no coordinate was ever entered" — null/undefined or an empty/whitespace-only
// string. A real numeric 0 is a legitimate coordinate and must NOT match this.
const blankCoordinate=v=>v==null||(typeof v==='string'&&v.trim()==='');
function checkReg(out,n,v,label){const result=controlledValueFinding(registry[n],v,label);if(result)out.push(result)}
function validate(r,i=records.indexOf(r)){const a=[];if(!r.name?.trim())a.push(['error','Name is missing.']);if(!r.id)a.push(['error','Stable ID is missing.']);// v0.7.2 (bug 2): a blank/missing coordinate used to pass this check silently, because
// Number('') === 0 — finite and in range — so "no coordinate at all" validated as a real point at
// exactly 0°,0° (and the minimap centred there). Missing is now its own error, checked BEFORE the
// range check so the message distinguishes "never entered" from "entered but out of range"; the
// range message itself is unchanged for records that really do carry an out-of-range number.
if(blankCoordinate(r.latitude))a.push(['error','Latitude is missing.']);else if(!Number.isFinite(Number(r.latitude))||Math.abs(Number(r.latitude))>90)a.push(['error','Latitude must be between −90 and 90.']);if(blankCoordinate(r.longitude))a.push(['error','Longitude is missing.']);else if(!Number.isFinite(Number(r.longitude))||Math.abs(Number(r.longitude))>180)a.push(['error','Longitude must be between −180 and 180.']);if(!r.canonicalType)a.push(['warning','Canonical Type is unresolved; uncertainty stays null + review, never Other.']);else checkReg(a,'types',r.canonicalType,'Type');r.tags.forEach(v=>checkReg(a,'tags',v,'Tag'));r.functions.forEach(v=>checkReg(a,'functions',v,'Function'));if(r.periodStart!==''&&r.periodEnd!==''&&+r.periodStart>+r.periodEnd)a.push(['error','Period start is later than period end.']);r.chronology.forEach(c=>{if(c.start?.year!==''&&c.end?.year!==''&&+c.start?.year>+c.end?.year)a.push(['error',`Chronology ${c.id||c.label} starts after it ends.`])});r.relationships.forEach(rel=>checkReg(a,'relationship-types',rel.relationshipType,'Relationship'));(r.evidence||[]).forEach(e=>checkReg(a,'evidence-forms',e.form,'Evidence form'));(r.conditionAssessments||[]).forEach(c=>checkReg(a,'conditions',c.condition,'Condition'));(r.investigations||[]).forEach(iv=>checkReg(a,'investigation-types',iv.type,'Investigation type'));a.push(...validateRelationships(r,records));if(!r.sources.length)a.push(['warning','No source recorded.']);if(r.needsResearch)a.push(['warning','Marked Needs Research.']);losses(r,i).filter(x=>x[0]==='warning').forEach(x=>a.push(['info',`Projection: ${x[2]}`]));return a}

const review=i=>reviewStates[records[i]?.id]||'unreviewed';
const isUntouched=(r,i)=>!isChanged(i)&&!(r.provenance&&Object.keys(r.provenance).length)&&!(r.workflow&&Object.keys(r.workflow).length);
// v0.7.2 (feature 1): the date-range half of the chronological navigator. Filters on periodStart
// only — periodEnd is deliberately NOT used: a proper overlapping-interval filter would need a
// second value AND a decision about what "overlaps" means for a record with a start but no end
// (most of them), which is a bigger question than this control needs to answer. Documented in
// IMPLEMENTATION_NOTES_v0.7.2.md.
const chronoBlank=v=>v===''||v==null||(typeof v==='string'&&v.trim()==='')||!Number.isFinite(Number(v));
const clampChrono=v=>Math.max(CHRONO_FLOOR,Math.min(CHRONO_CEIL,Math.round(v)));
function chronoPass(r){if(!chronoActive)return true;const v=r.periodStart;if(chronoBlank(v))return true;const n=Number(v);if(chronoBefore&&n<CHRONO_FLOOR)return true;if(chronoAfter&&n>CHRONO_CEIL)return true;return n>=chronoMin&&n<=chronoMax}
// Sort: "Catalogue order" (default) leaves the list exactly as it always was. Oldest/Newest sort
// by periodStart with UNDATED RECORDS ALWAYS LAST in both directions — one consistent end, so
// "newest first" never buries the dated records under 546 blanks either.
const chronoSortKey=r=>chronoBlank(r.periodStart)?null:Number(r.periodStart);
function sortRows(rows){if(recordSort==='catalogue')return rows;const dir=recordSort==='oldest'?1:-1;return rows.map((x,n)=>({x,n})).sort((a,b)=>{const ka=chronoSortKey(a.x.r),kb=chronoSortKey(b.x.r);if(ka===null&&kb===null)return a.n-b.n;if(ka===null)return 1;if(kb===null)return-1;return ka===kb?a.n-b.n:(ka-kb)*dir}).map(o=>o.x)}
function filtered(){const q=$('#search').value.trim().toLowerCase(),f=$('#issue-filter').value;return sortRows(records.map((r,i)=>({r,i})).filter(({r,i})=>{const h=[r.id,r.name,r.canonicalType,...r.cultures,...r.tags].join(' ').toLowerCase();return chronoPass(r)&&(!q||h.includes(q))&&(f==='all'||f==='changed'&&isChanged(i)||f==='issues'&&validate(r,i).length||f==='research'&&(r.needsResearch||review(i)==='research')||f==='proposal'&&recordHasPendingProposal(r.id)||f==='notype'&&!r.canonicalType||f==='notags'&&r.tags.length===0||f==='nosources'&&r.sources.length===0||f==='curatorflag'&&!!r.workflow?.curatorReview||f==='removal'&&!!r.workflow?.pendingRemoval||f==='untouched'&&isUntouched(r,i)||f===review(i))}))}
// v0.7.2 (feature 1): slider/field/toggle chrome. renderChronoNav() writes state → UI (never the
// other way round); renderChronoNote() is the "make it obvious, never silent" half — it states in
// plain text whether the filter is on, how many undated records are being shown regardless, and
// how many real outliers exist on each side of the working range plus whether they're in or out.
const chronoYearLabel=n=>n<0?`${Math.abs(n)} BC`:`AD ${n}`;
const chronoPct=v=>Math.max(0,Math.min(100,(v-CHRONO_FLOOR)/(CHRONO_CEIL-CHRONO_FLOOR)*100));
function renderChronoNav(){const tMin=$('#chrono-thumb-min'),tMax=$('#chrono-thumb-max');if(!tMin||!tMax)return;const pMin=chronoPct(chronoMin),pMax=chronoPct(chronoMax);tMin.style.left=pMin+'%';tMax.style.left=pMax+'%';tMin.title=chronoYearLabel(chronoMin);tMax.title=chronoYearLabel(chronoMax);tMin.setAttribute('aria-valuenow',String(chronoMin));tMax.setAttribute('aria-valuenow',String(chronoMax));const fill=$('#chrono-fill');if(fill){fill.style.left=pMin+'%';fill.style.width=Math.max(0,pMax-pMin)+'%'}const fMin=$('#chrono-min'),fMax=$('#chrono-max');if(fMin&&document.activeElement!==fMin)fMin.value=String(chronoMin);if(fMax&&document.activeElement!==fMax)fMax.value=String(chronoMax);$('#chrono-before')?.classList.toggle('active',chronoBefore);$('#chrono-after')?.classList.toggle('active',chronoAfter);const sortSel=$('#record-sort');if(sortSel)sortSel.value=recordSort}
function renderChronoNote(rows){const el=$('#chrono-note');if(!el)return;const undatedTotal=records.filter(r=>chronoBlank(r.periodStart)).length,undatedShown=rows.filter(({r})=>chronoBlank(r.periodStart)).length;const early=records.filter(r=>!chronoBlank(r.periodStart)&&Number(r.periodStart)<CHRONO_FLOOR).length,late=records.filter(r=>!chronoBlank(r.periodStart)&&Number(r.periodStart)>CHRONO_CEIL).length;const parts=[chronoActive?`Range <b>${esc(chronoYearLabel(chronoMin))} → ${esc(chronoYearLabel(chronoMax))}</b>`:'Date filter <b>off</b> — every year shown'];parts.push(`<b>${undatedShown}</b> of ${undatedTotal} undated record(s) shown (undated records are never hidden by this filter)`);parts.push(`Outside the working range: <b>${early}</b> before ${esc(chronoYearLabel(CHRONO_FLOOR))} (${chronoBefore?'forced in':'not forced in'}), <b>${late}</b> after ${esc(chronoYearLabel(CHRONO_CEIL))} (${chronoAfter?'forced in':'not forced in'})`);el.innerHTML=parts.join(' · ')}
function chronoValueFromX(clientX){const t=$('#chrono-track');if(!t)return CHRONO_FLOOR;const b=t.getBoundingClientRect(),pct=Math.max(0,Math.min(1,(clientX-b.left)/(b.width||1)));return clampChrono(CHRONO_FLOOR+pct*(CHRONO_CEIL-CHRONO_FLOOR))}
function setChrono(which,value){const v=clampChrono(value);if(which==='min')chronoMin=Math.min(v,chronoMax);else chronoMax=Math.max(v,chronoMin);chronoActive=true;renderChronoNav();renderList()}
function clearChrono(){chronoMin=CHRONO_FLOOR;chronoMax=CHRONO_CEIL;chronoActive=false;chronoBefore=false;chronoAfter=false;renderChronoNav();renderList();toast('Date filter cleared — showing every year again')}
function renderBulkBar(){const bar=$('#bulk-action-bar');if(!bar)return;bar.classList.toggle('hidden',bulkSelected.size===0);$('#bulk-count').textContent=`${bulkSelected.size} selected`}
function renderList(){const a=filtered();renderChronoNote(a);$('#record-list').innerHTML=a.map(({r,i})=>`<div class="record-item ${i===selected?'selected':''}" data-index="${i}" role="option"><input type="checkbox" class="bulk-check" data-bulk="${esc(r.id)}" ${bulkSelected.has(r.id)?'checked':''}><span class="record-flags">${isChanged(i)?'● ':''}${review(i)==='reviewed'?'✓ ':review(i)==='later'?'↩ ':review(i)==='research'?'? ':''}${validate(r,i).length?'⚠':''}${r.workflow?.pendingRemoval?'<span class="removal-flag" title="Marked for removal">🗑</span>':''}${unescoProposals[r.id]&&recordHasPendingProposal(r.id)?'<span class="proposal-flag">🏛</span>':recordHasPendingResearch(r.id)?'<span class="proposal-flag">🔎</span>':recordHasPendingReviewCandidate(r.id)?'<span class="proposal-flag">🧭</span>':recordHasPendingComponentCandidate(r.id)?'<span class="proposal-flag">🏗</span>':recordHasPendingPhaseCandidate(r.id)?'<span class="proposal-flag">📅</span>':''}</span><strong>${esc(r.name)}</strong><small>${esc(r.id)} · ${esc(r.canonicalType||'Unresolved')}</small></div>`).join('')||'<div class="record-item">No matching records.</div>';$('#list-count').textContent=`${a.length} of ${records.length} records`;$$('[data-index]').forEach(e=>e.onclick=()=>select(+e.dataset.index));$$('.bulk-check').forEach(cb=>{cb.onclick=e=>e.stopPropagation();cb.onchange=e=>{const id=e.target.dataset.bulk;if(e.target.checked)bulkSelected.add(id);else bulkSelected.delete(id);renderBulkBar()}});renderBulkBar()}
function markSelectedForRemoval(){const ids=[...bulkSelected];if(!ids.length)return;let count=0;for(const id of ids){const idx=records.findIndex(r=>r.id===id);if(idx<0)continue;const r=records[idx],merged={...(r.workflow||{}),pendingRemoval:{at:new Date().toISOString(),reason:'manual'}};try{const transaction=stageAdvancedTransaction(r,'workflow',JSON.stringify(merged),{registries:registry});records[idx]=transaction.after;history.push({index:idx,before:transaction.before,after:copy(transaction.after)});future=[];count++}catch{}}bulkSelected.clear();saveLocal();render();toast(`Marked ${count} record(s) for removal`)}
// v0.7.2: moving to a different record abandons any uncommitted coordinate edit (quietly — the
// user asked for another record, not for a toast about the one they left). Nothing was staged.
function select(i){cancelCoordEdit(true);commit();selected=Math.max(0,Math.min(records.length-1,i));render()}
function renderEnrichmentStatus(){const r=records[selected],el=$('#enrichment-status');if(!el)return;if(!r){el.innerHTML='';return}const chips=[{label:'Type',value:r.canonicalType||'—',need:!r.canonicalType},{label:'Tags',value:String(r.tags.length),need:r.tags.length===0},{label:'Dates',value:(r.periodStart!==''||r.periodEnd!=='')?`${r.periodStart===''?'?':r.periodStart} – ${r.periodEnd===''?'?':r.periodEnd}`:'—',need:r.periodStart===''&&r.periodEnd===''},{label:'Functions',value:String(r.functions.length),need:r.functions.length===0}];el.innerHTML=chips.map(c=>`<span class="enrichment-chip${c.need?' needflag':''}">${esc(c.label)}: ${esc(c.value)}${c.need?' <span class="needflag-badge">⚠ NEEDS ENRICHMENT</span>':''}</span>`).join('')}
function fill(){const r=records[selected];if(!r)return;$('#record-id').textContent=r.id;$('#record-title').textContent=r.name;$('#toggle-removal').textContent=r.workflow?.pendingRemoval?'RESTORE':'MARK FOR REMOVAL';const menuMarkRemoval=$('#menu-mark-removal');if(menuMarkRemoval){menuMarkRemoval.textContent=r.workflow?.pendingRemoval?'Restore':'Mark for Removal';menuMarkRemoval.disabled=false}renderEnrichmentStatus();renderedSources=sourceText(r.sources);for(const el of $('#record-form').elements){if(!el.name||el.name.startsWith('tax-'))continue;if(el.type==='checkbox')el.checked=!!r[el.name];else if(arrayFields.includes(el.name))el.value=(r[el.name]||[]).join('; ');else if(el.name==='sources')el.value=renderedSources;else el.value=r[el.name]??''}taxSelections={type:r.canonicalType?[r.canonicalType]:[],tags:copy(r.tags),functions:copy(r.functions)};renderTaxonomies();renderPhases(r.phases);renderChronologyRows(r.chronology);renderComponentRows(r.components);renderRelationshipRows(r.relationships);renderEvidenceRows(r.evidence);renderConditionRows(r.conditionAssessments);renderInvestigationRows(r.investigations);renderedPhases=JSON.stringify(readPhases());renderedChronology=JSON.stringify(readChronology());renderedComponents=JSON.stringify(readComponents());renderedRelationships=JSON.stringify(readRelationships());renderedEvidence=JSON.stringify(readEvidence());renderedConditions=JSON.stringify(readConditions());renderedInvestigations=JSON.stringify(readInvestigations());renderMap();renderReview();renderChanges();renderValidation();renderPreview();renderAdvanced();renderAudit();renderProposalPanel();renderResearchPanel();renderReviewPanel();renderComponentPanel();renderPhasePanel();$('#dirty-badge').classList.toggle('hidden',!isChanged(selected));$('#position-status').textContent=`Record ${selected+1} of ${records.length}`;renderDistance()}
function formRecord(){const r=copy(records[selected]),fd=new FormData($('#record-form'));for(const[k,v]of fd){if(k.startsWith('tax-'))continue;if(arrayFields.includes(k))r[k]=list(v);else if(k==='sources'){if(v!==renderedSources)r[k]=v.split('\n').map(x=>x.trim()).filter(Boolean)}else if(['latitude','longitude','periodStart','periodEnd'].includes(k))r[k]=num(v);else r[k]=v}r.canonicalType=taxSelections.type[0]||'';r.tags=copy(taxSelections.tags);r.functions=copy(taxSelections.functions);r.needsResearch=$('[name=needsResearch]').checked;const p=readPhases(),c=readChronology(),com=readComponents(),rel=readRelationships(),ev=readEvidence(),cond=readConditions(),inv=readInvestigations();if(JSON.stringify(p)!==renderedPhases)r.phases=p;if(JSON.stringify(c)!==renderedChronology)r.chronology=c;if(JSON.stringify(com)!==renderedComponents)r.components=com;if(JSON.stringify(rel)!==renderedRelationships)r.relationships=rel;if(JSON.stringify(ev)!==renderedEvidence)r.evidence=ev;if(JSON.stringify(cond)!==renderedConditions)r.conditionAssessments=cond;if(JSON.stringify(inv)!==renderedInvestigations)r.investigations=inv;return r}
function commit(push=true){if(!records[selected])return;const next=formRecord(),prev=records[selected];if(JSON.stringify(next)===JSON.stringify(prev))return;const transaction=stageRecordReplacement(prev,next);if(push){history.push({index:selected,before:transaction.before,after:transaction.after});future=[]}records[selected]=transaction.after;saveLocal();render()}
const sourceText=a=>(a||[]).map(x=>typeof x==='string'?x:(x.url||x.title||JSON.stringify(x))).join('\n');

function vocab(field){const n=field==='type'?'types':field,s=new Set(entries(n).map(e=>e.id));records.forEach(r=>{const v=field==='type'?r.canonicalType:r[field];(Array.isArray(v)?v:[v]).filter(Boolean).forEach(x=>s.add(String(x)))});return[...s].sort()}
function renderTaxonomies(){$$('.taxonomy-field').forEach(renderTaxonomy)}
function renderTaxonomy(el){const field=el.dataset.taxonomy,n=field==='type'?'types':field,vals=taxSelections[field],q=el.querySelector('.taxonomy-search').value.toLowerCase();el.querySelector('.taxonomy-chips').innerHTML=vals.map(v=>{const s=status[n]?.get(v)||'unknown';return`<span class="taxonomy-chip ${s==='active'?'':s}">${esc(v)}${s!=='active'?`<span class="registry-state ${s}">${s}</span>`:''}<button type="button" data-remove-tax="${esc(v)}">×</button></span>`}).join('')||'<span class="empty-taxonomy">None selected</span>';el.querySelector('.taxonomy-options').innerHTML=vocab(field).filter(v=>v.toLowerCase().includes(q)).map(v=>{const s=status[n]?.get(v)||'unknown';return`<label class="taxonomy-option"><input type="${field==='type'?'radio':'checkbox'}" name="tax-${field}" value="${esc(v)}" ${vals.includes(v)?'checked':''}> ${esc(v)}${s!=='active'?` <span class="registry-state ${s}">${s}</span>`:''}</label>`}).join('');el.querySelectorAll('[data-remove-tax]').forEach(b=>b.onclick=()=>setTax(field,b.dataset.removeTax,false));el.querySelectorAll('.taxonomy-option input').forEach(i=>i.onchange=()=>setTax(field,i.value,i.checked))}
function setTax(field,v,on){taxSelections[field]=field==='type'?(on?[v]:[]):(on?[...new Set([...taxSelections[field],v])]:taxSelections[field].filter(x=>x!==v));renderTaxonomy($(`[data-taxonomy="${field}"]`))}

function phaseHTML(p={}){return`<div class="phase-row"><input class="inset" data-phase="label" value="${esc(p.label||p.name||'')}" placeholder="Phase"><select class="inset" data-phase="type"><option></option>${entries('phase-types').map(e=>`<option ${e.id===p.type?'selected':''}>${esc(e.id)}</option>`).join('')}</select><input class="inset" data-phase="chronologyIds" value="${esc((p.chronologyIds||[]).join('; '))}" placeholder="Chronology IDs"><span class="derived-date" title="Derived from linked chronology; not directly editable">${esc(p.start??p.periodStart??'—')} → ${esc(p.end??p.periodEnd??'—')}</span><button type="button" class="win-button row-remove">×</button></div>`}
function renderPhases(a){$('#phases-editor').innerHTML=(a||[]).map(phaseHTML).join('')||'<div class="empty-phases">No phases recorded.</div>';bindRemovers('#phases-editor')}
function readPhases(){return $$('#phases-editor .phase-row').map((row,i)=>({...(records[selected].phases?.[i]||{}),id:records[selected].phases?.[i]?.id||`phase-${i+1}`,label:row.querySelector('[data-phase=label]').value.trim(),type:row.querySelector('[data-phase=type]').value,chronologyIds:list(row.querySelector('[data-phase=chronologyIds]').value)}))}
function chronologyHTML(c={}){return`<div class="chronology-row"><input class="inset" data-chron="label" value="${esc(c.label||c.id||'')}" placeholder="Label"><input class="inset" data-chron="start" type="number" value="${c.start?.year??c.periodStart??''}" placeholder="Start"><input class="inset" data-chron="end" type="number" value="${c.end?.year??c.periodEnd??''}" placeholder="End"><select class="inset" data-chron="qualifier">${['','exact','circa','before','after','between'].map(v=>`<option ${v===(c.start?.qualifier||'')?'selected':''}>${v}</option>`).join('')}</select><button type="button" class="win-button row-remove">×</button></div>`}
function renderChronologyRows(a){$('#chronology-editor').innerHTML=(a||[]).map(chronologyHTML).join('')||'<div class="empty-phases">No chronology assertions.</div>';bindRemovers('#chronology-editor')}
function readChronology(){return $$('#chronology-editor .chronology-row').map((row,i)=>{const old=records[selected].chronology?.[i]||{},q=row.querySelector('[data-chron=qualifier]').value;return{...old,id:old.id||`chronology-${i+1}`,label:row.querySelector('[data-chron=label]').value.trim(),start:{...(old.start||{}),year:num(row.querySelector('[data-chron=start]').value),qualifier:q||undefined},end:{...(old.end||{}),year:num(row.querySelector('[data-chron=end]').value),qualifier:q||undefined}}})}
function componentHTML(c={}){return`<div class="component-row"><input class="inset" data-component="label" value="${esc(c.label||'')}" placeholder="Component label"><input class="inset" data-component="chronologyIds" value="${esc((c.chronologyIds||[]).join('; '))}" placeholder="Chronology IDs"><input class="inset" data-component="siteId" value="${esc(c.representedBySiteId||'')}" placeholder="Represented by Site ID"><button type="button" class="win-button row-remove">×</button></div>`}
function renderComponentRows(a){$('#components-editor').innerHTML=(a||[]).map(componentHTML).join('')||'<div class="empty-phases">No components recorded.</div>';bindRemovers('#components-editor')}
function readComponents(){return $$('#components-editor .component-row').map((row,i)=>({...(records[selected].components?.[i]||{}),id:records[selected].components?.[i]?.id||`component-${i+1}`,label:row.querySelector('[data-component=label]').value.trim(),chronologyIds:list(row.querySelector('[data-component=chronologyIds]').value),representedBySiteId:row.querySelector('[data-component=siteId]').value.trim()||null}))}
function relationshipHTML(rel={}){return`<div class="relationship-row"><select class="inset" data-rel="type"><option></option>${entries('relationship-types').map(e=>`<option ${e.id===rel.relationshipType?'selected':''}>${esc(e.id)}</option>`).join('')}</select><input class="inset" data-rel="target" value="${esc(rel.targetSiteId||'')}" placeholder="Target Site ID"><input class="inset" data-rel="pair" value="${esc(rel.pairId||'')}" placeholder="Pair ID"><button type="button" class="win-button row-remove">×</button></div>`}
function renderRelationshipRows(a){$('#relationships-editor').innerHTML=(a||[]).map(relationshipHTML).join('')||'<div class="empty-phases">No site relationships.</div>';bindRemovers('#relationships-editor')}
function readRelationships(){return $$('#relationships-editor .relationship-row').map((row,i)=>({...(records[selected].relationships?.[i]||{}),id:records[selected].relationships?.[i]?.id||`relationship-${i+1}`,relationshipType:row.querySelector('[data-rel=type]').value,targetSiteId:row.querySelector('[data-rel=target]').value.trim(),pairId:row.querySelector('[data-rel=pair]').value.trim()}))}
function bindRemovers(scope){$$(scope+' .row-remove').forEach(b=>b.onclick=()=>b.parentElement.remove())}

// v0.5.6: enrichment-dimension editors (Evidence, Condition Assessments, Investigations).
// These were previously only reachable through the raw Advanced Canonical Dimensions JSON
// textarea — real form fields, following the exact same row-editor pattern already used
// for phases/chronology/components/relationships, so enrichment doesn't require hand-typed
// JSON. registries (`evidence-forms`, `conditions`, `investigation-types`) drive the
// dropdowns; unknown/deprecated values already picked stay selectable and are flagged by
// validate() rather than silently dropped from the option list.
function evidenceHTML(e={}){return`<div class="evidence-row"><select class="inset" data-evidence="form"><option></option>${entries('evidence-forms').map(x=>`<option ${x.id===e.form?'selected':''}>${esc(x.id)}</option>`).join('')}</select><input class="inset" data-evidence="description" value="${esc(e.description||'')}" placeholder="Description"><input class="inset" data-evidence="source" value="${esc(e.source||'')}" placeholder="Source"><button type="button" class="win-button row-remove">×</button></div>`}
function renderEvidenceRows(a){$('#evidence-editor').innerHTML=(a||[]).map(evidenceHTML).join('')||'<div class="empty-phases">No evidence recorded.</div>';bindRemovers('#evidence-editor')}
function readEvidence(){return $$('#evidence-editor .evidence-row').map((row,i)=>({...(records[selected].evidence?.[i]||{}),id:records[selected].evidence?.[i]?.id||`evidence-${i+1}`,form:row.querySelector('[data-evidence=form]').value,description:row.querySelector('[data-evidence=description]').value.trim(),source:row.querySelector('[data-evidence=source]').value.trim()}))}

function conditionHTML(c={}){return`<div class="condition-row"><select class="inset" data-condition="condition"><option></option>${entries('conditions').map(x=>`<option ${x.id===c.condition?'selected':''}>${esc(x.id)}</option>`).join('')}</select><input class="inset" data-condition="assessedAt" value="${esc(c.assessedAt||'')}" placeholder="Assessed (date/year)"><input class="inset" data-condition="notes" value="${esc(c.notes||'')}" placeholder="Notes"><button type="button" class="win-button row-remove">×</button></div>`}
function renderConditionRows(a){$('#condition-editor').innerHTML=(a||[]).map(conditionHTML).join('')||'<div class="empty-phases">No condition assessments recorded.</div>';bindRemovers('#condition-editor')}
function readConditions(){return $$('#condition-editor .condition-row').map((row,i)=>({...(records[selected].conditionAssessments?.[i]||{}),id:records[selected].conditionAssessments?.[i]?.id||`condition-${i+1}`,condition:row.querySelector('[data-condition=condition]').value,assessedAt:row.querySelector('[data-condition=assessedAt]').value.trim(),notes:row.querySelector('[data-condition=notes]').value.trim()}))}

function investigationHTML(iv={}){return`<div class="investigation-row"><select class="inset" data-investigation="type"><option></option>${entries('investigation-types').map(x=>`<option ${x.id===iv.type?'selected':''}>${esc(x.id)}</option>`).join('')}</select><input class="inset" data-investigation="date" value="${esc(iv.date||'')}" placeholder="Date/year"><input class="inset" data-investigation="notes" value="${esc(iv.notes||'')}" placeholder="Investigator / notes"><button type="button" class="win-button row-remove">×</button></div>`}
function renderInvestigationRows(a){$('#investigation-editor').innerHTML=(a||[]).map(investigationHTML).join('')||'<div class="empty-phases">No investigations recorded.</div>';bindRemovers('#investigation-editor')}
function readInvestigations(){return $$('#investigation-editor .investigation-row').map((row,i)=>({...(records[selected].investigations?.[i]||{}),id:records[selected].investigations?.[i]?.id||`investigation-${i+1}`,type:row.querySelector('[data-investigation=type]').value,date:row.querySelector('[data-investigation=date]').value.trim(),notes:row.querySelector('[data-investigation=notes]').value.trim()}))}

// Read-only summary of the machine/pipeline-managed dimensions (workflow, provenance,
// heritage, dataQuality). These are populated by migration scripts and Curator's UNESCO
// pipeline with deep, dynamically-keyed audit data (rule IDs, proposal fingerprints,
// retrieval timestamps) that no curator should hand-type — see CHANGELOG_v0.5.6.md. This
// panel makes that state visible without inventing an editor for it; the Advanced JSON
// escape hatch remains the (rare, power-user) way to edit these directly.
function summarizeDimension(obj,depth=0){if(obj==null)return'—';if(Array.isArray(obj))return`${obj.length} entr${obj.length===1?'y':'ies'}`;if(typeof obj==='object')return depth>0?'{…}':Object.entries(obj).map(([k,v])=>`<div class="audit-row"><b>${esc(k)}</b><span>${summarizeDimension(v,depth+1)}</span></div>`).join('')||'empty';return esc(String(obj))}
function renderAudit(){const r=records[selected];if(!r)return$('#audit-summary').innerHTML='';const parts=[];// v0.7.0: workflow now also carries curatorReview (Curator stage decisions) and
// pendingRemoval (Editor staged removal) — arbitrary-shaped objects with no `.state` field,
// unlike the enrichment-state entries this renderer was originally written for. Fall back to
// a flat "key: value · key: value" summary of the object's own fields, instead of showing a
// bare "—", so any new workflow shape stays visible here without a dedicated editor.
const summarizeWorkflowObject=v=>Object.entries(v).map(([kk,vv])=>`${esc(kk)}: ${esc(typeof vv==='object'&&vv!==null?JSON.stringify(vv):String(vv))}`).join(' · ')||'empty';
const wf=r.workflow&&Object.keys(r.workflow).length?Object.entries(r.workflow).map(([k,v])=>Array.isArray(v)?`<div class="audit-row"><b>${esc(k)}</b><span>${v.length} flagged${v.length?': '+v.map(x=>esc(x.reason||x)).join(', '):''}</span></div>`:v&&typeof v==='object'&&'state' in v?`<div class="audit-row"><b>${esc(k)}</b><span>${esc(v.state||'—')}${v.enteredAt?' · since '+esc(v.enteredAt):''}${v.resolvedAt?' · resolved '+esc(v.resolvedAt):''}</span></div>`:v&&typeof v==='object'?`<div class="audit-row"><b>${esc(k)}</b><span>${summarizeWorkflowObject(v)}</span></div>`:`<div class="audit-row"><b>${esc(k)}</b><span>${esc(v??'—')}</span></div>`).join(''):'<div class="empty-phases">No open workflow items.</div>';parts.push(`<b>Workflow</b>${wf}`);const prov=r.provenance&&Object.keys(r.provenance).length?Object.entries(r.provenance).map(([k,v])=>Array.isArray(v)?`<div class="audit-row"><b>${esc(k)}</b><span>${v.length} entries</span></div>`:`<div class="audit-row"><b>${esc(k)}</b><span>${esc(v?.method||'—')}${v?.ruleId?' · '+esc(v.ruleId):''}</span></div>`).join(''):'<div class="empty-phases">No provenance recorded.</div>';parts.push(`<b>Provenance</b>${prov}`);const unesco=r.heritage?.unesco;const her=unesco?`<div class="audit-row"><b>UNESCO</b><span>${esc(unesco.officialName||'')} (#${esc(unesco.source?.unescoId||'?')})${unesco.source?.url?` — <a href="${esc(unesco.source.url)}" target="_blank" rel="noopener">link</a>`:''}</span></div>`:'<div class="empty-phases">No heritage designation recorded.</div>';parts.push(`<b>Heritage</b>${her}`);const dq=r.dataQuality&&Object.keys(r.dataQuality).length?Object.entries(r.dataQuality).map(([k,v])=>`<div class="audit-row"><b>${esc(k)}</b><span>${summarizeDimension(v,1)}</span></div>`).join(''):'<div class="empty-phases">No data-quality flags.</div>';parts.push(`<b>Data quality</b>${dq}`);$('#audit-summary').innerHTML=parts.join('')}

// v0.6.0: enrichment-adapter proposal review (first adapter: UNESCO — see
// scripts/unesco-enrichment-adapter.mjs). A proposal file is generated offline
// by an adapter (adapter -> raw evidence -> proposal, per the governance model)
// and loaded here via LOAD PROPOSALS; nothing in it ever writes to a record
// directly. Applying a proposal merges its fields and re-uses the exact same
// stageAdvancedTransaction() path as the Advanced JSON textarea, so an applied
// proposal is validated, staged, undoable, and autosaved exactly like any other
// hand-typed edit — the adapter only pre-fills what a curator would otherwise
// have had to type.
function proposalStatus(id,kind){return proposalDecisions[`${id}:${kind}`]||'pending'}
function setProposalStatus(id,kind,status){proposalDecisions[`${id}:${kind}`]=status}
function recordHasPendingProposal(id){const p=unescoProposals[id];const hasUnesco=p&&!!((p.heritageProposal&&proposalStatus(id,'heritage')==='pending')||(p.evidenceProposal&&proposalStatus(id,'evidence')==='pending'));return hasUnesco||recordHasPendingResearch(id)}
function loadProposals(file){const fr=new FileReader();fr.onload=()=>{try{const list=JSON.parse(fr.result);if(!Array.isArray(list))throw Error('Expected a JSON array of proposals.');let added=0;for(const p of list){if(!p.recordId)continue;unescoProposals[p.recordId]=p;added++}saveLocal();render();toast(`Loaded ${added} proposal(s) from ${file.name}`)}catch(e){toast('Could not load proposals: '+e.message)}};fr.readAsText(file)}

// v0.6.5: research proposals (adapter: scripts/wikidata-research-adapter.mjs). Same governance
// shape as the UNESCO enrichment proposals above (adapter -> evidence -> proposal, applied only
// through the existing staging paths — stageAdvancedTransaction for the evidence array,
// stageRecordReplacement for canonicalType/tags/period, the same functions commit()/the UNESCO
// proposals already use) — but keyed by recordId with up to three independently-applicable parts
// per record (evidence / suggested type / suggested period), since one Wikidata lookup can offer
// none, some, or all three depending on what was found. A "matched" proposal with nothing
// actionable (no extract, no table hit, no dates) and "no-match"/"ambiguous"/"error" statuses are
// still loaded and shown — they're proof research was attempted, even when there's nothing to
// apply — but never count toward the pending-proposal flag.
function researchStatus(id,kind){return researchDecisions[`${id}:${kind}`]||'pending'}
function setResearchStatus(id,kind,value){researchDecisions[`${id}:${kind}`]=value}
function recordHasPendingResearch(id){const p=researchProposals[id];if(!p||p.status!=='matched')return false;const e=p.evidenceProposal&&researchStatus(id,'evidence')==='pending';const t=p.suggestedType&&researchStatus(id,'type')==='pending';const d=p.periodSuggestion&&researchStatus(id,'period')==='pending';const pe=p.pleiadesEvidenceProposal&&researchStatus(id,'pleiadesEvidence')==='pending';return!!(e||t||d||pe)}
function loadResearchProposals(file){const fr=new FileReader();fr.onload=()=>{try{const list=JSON.parse(fr.result);if(!Array.isArray(list))throw Error('Expected a JSON array of proposals.');let added=0;for(const p of list){if(!p.recordId)continue;researchProposals[p.recordId]=p;added++}saveLocal();render();toast(`Loaded ${added} research proposal(s) from ${file.name}`)}catch(e){toast('Could not load research proposals: '+e.message)}};fr.readAsText(file)}
// Merges scripts/pleiades-research-adapter.mjs output into the SAME per-record research
// proposal object the Wikidata pass populates, rather than a separate proposals map — this is
// what lets a Type or period suggestion Pleiades found (only ever produced when the Wikidata
// pass left that field empty — see that adapter's own merge logic) apply through the exact same
// APPLY TYPE / APPLY PERIOD buttons and stageRecordReplacement path already governing those,
// with no new code path to keep in sync. Evidence is the one field that's always independent —
// pleiadesEvidenceProposal never overwrites evidenceProposal — because a Pleiades citation and a
// Wikipedia citation are two different, both-worth-having sources, applied separately below.
// A record with no Wikidata proposal loaded yet still gets a minimal shell entry so its Pleiades
// data can render — the panel guards every Wikidata-specific field (p.match) for that case.
function loadPleiadesProposals(file){const fr=new FileReader();fr.onload=()=>{try{const list=JSON.parse(fr.result);if(!Array.isArray(list))throw Error('Expected a JSON array of proposals.');let added=0;for(const p of list){if(!p.recordId||p.status!=='matched')continue;const target=researchProposals[p.recordId]||{recordId:p.recordId,recordName:p.recordName,status:'matched',match:null,sourceUrl:null,evidenceProposal:null,suggestedType:null,coordinateCheck:null,periodSuggestion:null};target.pleiadesId=p.pleiadesId;target.pleiadesTitle=p.title;target.pleiadesSourceUrl=p.sourceUrl;target.pleiadesEvidenceProposal=p.pleiadesEvidenceProposal||null;target.pleiadesCoordinateCheck=p.coordinateCheck||null;if(!target.suggestedType&&p.suggestedType)target.suggestedType=p.suggestedType;if(!target.periodSuggestion&&p.periodSuggestion)target.periodSuggestion=p.periodSuggestion;researchProposals[p.recordId]=target;added++}saveLocal();render();toast(`Loaded ${added} Pleiades proposal(s) from ${file.name}`)}catch(e){toast('Could not load Pleiades proposals: '+e.message)}};fr.readAsText(file)}

const proposalFieldLabels={areaHectares:'Area (ha)',criteria:'Criteria',dateInscribed:'Inscribed',secondaryDates:'Secondary dates',dangerListed:'Danger-listed',dangerListedNote:'Danger note',dateEnd:'Delisted',transboundary:'Transboundary',componentsCount:'Components',image:'Lead image',sourceUuid:'Source UUID'};
function proposalFieldValue(v){if(v==null)return'—';if(typeof v==='boolean')return v?'yes':'no';if(typeof v==='object')return v.text?`${v.text}${v.cultural?' · '+v.cultural:''}${v.natural?' · '+v.natural:''}`:(v.url?(v.caption||v.url):JSON.stringify(v));return String(v)}
function renderProposalPanel(){const r=records[selected],panel=$('#proposal-panel');if(!panel)return;if(!r||!unescoProposals[r.id]){panel.classList.add('hidden');panel.innerHTML='';return}
  const p=unescoProposals[r.id],hStatus=proposalStatus(r.id,'heritage'),eStatus=proposalStatus(r.id,'evidence');
  const eAlreadyPresent=!!(p.evidenceProposal&&(r.evidence||[]).some(x=>x.source===p.evidenceProposal.source));
  const hPending=p.heritageProposal&&hStatus==='pending',ePending=p.evidenceProposal&&eStatus==='pending'&&!eAlreadyPresent;
  panel.classList.remove('hidden');
  let html=`<div class="proposal-card"><h4>🏛 Enrichment proposal</h4><div class="proposal-source">${esc(p.officialName||'')} — <a href="${esc(p.sourceUrl)}" target="_blank" rel="noopener">official listing #${esc(p.unescoId)}</a></div>`;
  if(p.heritageProposal){
    html+=hPending?`<div class="proposal-field-list">${Object.entries(p.heritageProposal).map(([k,v])=>`<div class="audit-row"><b>${esc(proposalFieldLabels[k]||k)}</b><span>${esc(proposalFieldValue(v))}</span></div>`).join('')}</div><div class="proposal-actions"><button type="button" class="win-button compact primary" data-apply-heritage>APPLY TO HERITAGE</button><button type="button" class="win-button compact" data-dismiss-heritage>DISMISS</button></div>`:`<p class="proposal-status">Heritage fields: ${esc(hStatus)}.</p>`;
  }
  if(p.evidenceProposal){
    html+=ePending?`<div class="proposal-field-list"><div class="audit-row"><b>Form</b><span>${esc(p.evidenceProposal.form)}</span></div><div class="audit-row"><b>Description</b><span>${esc(p.evidenceProposal.description)}</span></div><div class="audit-row"><b>Source</b><span>${esc(p.evidenceProposal.source)}</span></div></div><div class="proposal-actions"><button type="button" class="win-button compact primary" data-apply-evidence>APPLY AS EVIDENCE</button><button type="button" class="win-button compact" data-dismiss-evidence>DISMISS</button></div>`:`<p class="proposal-status">Evidence citation: ${esc(eAlreadyPresent&&eStatus==='pending'?'already present':eStatus)}.</p>`;
  }
  html+='</div>';panel.innerHTML=html;
  panel.querySelector('[data-apply-heritage]')?.addEventListener('click',applyHeritageProposal);
  panel.querySelector('[data-dismiss-heritage]')?.addEventListener('click',()=>{setProposalStatus(r.id,'heritage','dismissed');saveLocal();render();toast('Heritage proposal dismissed')});
  panel.querySelector('[data-apply-evidence]')?.addEventListener('click',applyEvidenceProposal);
  panel.querySelector('[data-dismiss-evidence]')?.addEventListener('click',()=>{setProposalStatus(r.id,'evidence','dismissed');saveLocal();render();toast('Evidence proposal dismissed')});
}
function applyHeritageProposal(){const r=records[selected],p=unescoProposals[r.id];if(!p?.heritageProposal)return;const merged={...(r.heritage||{}),unesco:{...(r.heritage?.unesco||{}),...p.heritageProposal}};try{const transaction=stageAdvancedTransaction(r,'heritage',JSON.stringify(merged),{registries:registry});records[selected]=transaction.after;history.push({index:selected,before:transaction.before,after:copy(transaction.after)});future=[];setProposalStatus(r.id,'heritage','applied');saveLocal();render();toast('Heritage proposal applied')}catch(e){toast('Could not apply proposal: '+e.message)}}
function applyEvidenceProposal(){const r=records[selected],p=unescoProposals[r.id];if(!p?.evidenceProposal)return;if((r.evidence||[]).some(x=>x.source===p.evidenceProposal.source)){setProposalStatus(r.id,'evidence','applied');saveLocal();render();return}const merged=[...(r.evidence||[]),{id:`evidence-unesco-${p.unescoId}`,...p.evidenceProposal}];try{const transaction=stageAdvancedTransaction(r,'evidence',JSON.stringify(merged),{registries:registry});records[selected]=transaction.after;history.push({index:selected,before:transaction.before,after:copy(transaction.after)});future=[];setProposalStatus(r.id,'evidence','applied');saveLocal();render();toast('Evidence citation applied')}catch(e){toast('Could not apply proposal: '+e.message)}}

function renderResearchPanel(){const r=records[selected],panel=$('#research-panel');if(!panel)return;const p=r&&researchProposals[r.id];if(!p){panel.classList.add('hidden');panel.innerHTML='';return}
  panel.classList.remove('hidden');
  let html=`<div class="proposal-card"><h4>🔎 Research proposal</h4>`;
  if(p.status==='no-match'){html+=`<p class="proposal-status">No confident Wikidata match found for “${esc(p.recordName)}.”</p></div>`;panel.innerHTML=html;return}
  if(p.status==='error'){html+=`<p class="proposal-status">Lookup failed: ${esc(p.error||'unknown error')}.</p></div>`;panel.innerHTML=html;return}
  if(p.status==='ambiguous'){html+=`<p class="proposal-status">Multiple possible Wikidata matches — pick one manually:</p><ul class="validation-list">${(p.alternates||[]).map(a=>`<li>${esc(a.label)} (${esc(a.qid)})${a.description?' — '+esc(a.description):''}</li>`).join('')}</ul></div>`;panel.innerHTML=html;return}
  if(p.match){html+=`<div class="proposal-source">${esc(p.match.label||'')} (${esc(p.match.qid||'')}, ${esc(p.match.confidence||'')} confidence) — <a href="${esc(p.sourceUrl)}" target="_blank" rel="noopener">Wikipedia</a></div>`}
  const eStatus=researchStatus(r.id,'evidence'),tStatus=researchStatus(r.id,'type'),dStatus=researchStatus(r.id,'period'),peStatus=researchStatus(r.id,'pleiadesEvidence');
  const eAlreadyPresent=!!(p.evidenceProposal&&(r.evidence||[]).some(x=>x.source===p.evidenceProposal.source));
  const ePending=p.evidenceProposal&&eStatus==='pending'&&!eAlreadyPresent,tPending=p.suggestedType&&tStatus==='pending',dPending=p.periodSuggestion&&dStatus==='pending';
  if(p.evidenceProposal){
    html+=ePending?`<div class="proposal-field-list"><div class="audit-row"><b>Extract</b><span>${esc(p.evidenceProposal.description)}</span></div></div><div class="proposal-actions"><button type="button" class="win-button compact primary" data-apply-research-evidence>APPLY AS EVIDENCE</button><button type="button" class="win-button compact" data-dismiss-research-evidence>DISMISS</button></div>`:`<p class="proposal-status">Evidence citation: ${esc(eAlreadyPresent&&eStatus==='pending'?'already present':eStatus)}.</p>`;
  }
  if(p.suggestedType){
    html+=tPending?`<div class="proposal-field-list"><div class="audit-row"><b>Type</b><span>${esc(p.suggestedType.type)}</span></div><div class="audit-row"><b>Tags</b><span>${esc(p.suggestedType.tags.join(', ')||'—')}</span></div><div class="audit-row"><b>Why</b><span>${esc(p.suggestedType.rationale)}</span></div></div><div class="proposal-actions"><button type="button" class="win-button compact primary" data-apply-research-type>APPLY TYPE</button><button type="button" class="win-button compact" data-dismiss-research-type>DISMISS</button></div>`:`<p class="proposal-status">Suggested type: ${esc(tStatus)}.</p>`;
  }
  if(p.periodSuggestion){
    const confNote=p.periodSuggestion.confidence==='low'?' <em>(approximate estimate — verify before applying)</em>':'';
    html+=dPending?`<div class="proposal-field-list"><div class="audit-row"><b>Period start</b><span>${esc(p.periodSuggestion.periodStart??'—')}</span></div><div class="audit-row"><b>Period end</b><span>${esc(p.periodSuggestion.periodEnd??'—')}</span></div><div class="audit-row"><b>Why</b><span>${esc(p.periodSuggestion.rationale)}${confNote}</span></div></div><div class="proposal-actions"><button type="button" class="win-button compact primary" data-apply-research-period>APPLY PERIOD</button><button type="button" class="win-button compact" data-dismiss-research-period>DISMISS</button></div>`:`<p class="proposal-status">Suggested period: ${esc(dStatus)}.</p>`;
  }
  if(p.coordinateCheck?.flag){
    html+=`<p class="proposal-status warning">⚠ Wikidata's coordinates are ~${Math.round(p.coordinateCheck.distanceMeters/1000)}km from this record's — worth a manual check.</p>`;
  }
  if(p.pleiadesEvidenceProposal){
    const peAlreadyPresent=!!(r.evidence||[]).some(x=>x.source===p.pleiadesEvidenceProposal.source);
    const pePending=peStatus==='pending'&&!peAlreadyPresent;
    html+=`<div class="proposal-source">Pleiades: ${esc(p.pleiadesTitle||p.recordName||'')} — <a href="${esc(p.pleiadesSourceUrl)}" target="_blank" rel="noopener">pleiades.stoa.org</a></div>`;
    html+=pePending?`<div class="proposal-field-list"><div class="audit-row"><b>Extract</b><span>${esc(p.pleiadesEvidenceProposal.description)}</span></div></div><div class="proposal-actions"><button type="button" class="win-button compact primary" data-apply-research-pleiades-evidence>APPLY AS EVIDENCE (PLEIADES)</button><button type="button" class="win-button compact" data-dismiss-research-pleiades-evidence>DISMISS</button></div>`:`<p class="proposal-status">Pleiades evidence citation: ${esc(peAlreadyPresent&&peStatus==='pending'?'already present':peStatus)}.</p>`;
  }
  if(p.pleiadesCoordinateCheck?.flag){
    html+=`<p class="proposal-status warning">⚠ Pleiades' coordinates are ~${Math.round(p.pleiadesCoordinateCheck.distanceMeters/1000)}km from this record's — worth a manual check.</p>`;
  }
  html+='</div>';panel.innerHTML=html;
  panel.querySelector('[data-apply-research-evidence]')?.addEventListener('click',applyResearchEvidence);
  panel.querySelector('[data-dismiss-research-evidence]')?.addEventListener('click',()=>{setResearchStatus(r.id,'evidence','dismissed');saveLocal();render();toast('Research evidence dismissed')});
  panel.querySelector('[data-apply-research-type]')?.addEventListener('click',applyResearchType);
  panel.querySelector('[data-dismiss-research-type]')?.addEventListener('click',()=>{setResearchStatus(r.id,'type','dismissed');saveLocal();render();toast('Suggested type dismissed')});
  panel.querySelector('[data-apply-research-period]')?.addEventListener('click',applyResearchPeriod);
  panel.querySelector('[data-dismiss-research-period]')?.addEventListener('click',()=>{setResearchStatus(r.id,'period','dismissed');saveLocal();render();toast('Suggested period dismissed')});
  panel.querySelector('[data-apply-research-pleiades-evidence]')?.addEventListener('click',applyResearchPleiadesEvidence);
  panel.querySelector('[data-dismiss-research-pleiades-evidence]')?.addEventListener('click',()=>{setResearchStatus(r.id,'pleiadesEvidence','dismissed');saveLocal();render();toast('Pleiades evidence dismissed')});
}
function applyResearchEvidence(){const r=records[selected],p=researchProposals[r.id];if(!p?.evidenceProposal)return;if((r.evidence||[]).some(x=>x.source===p.evidenceProposal.source)){setResearchStatus(r.id,'evidence','applied');saveLocal();render();return}const merged=[...(r.evidence||[]),{id:`evidence-research-${p.match?.qid||r.id}`,...p.evidenceProposal}];try{const transaction=stageAdvancedTransaction(r,'evidence',JSON.stringify(merged),{registries:registry});records[selected]=transaction.after;history.push({index:selected,before:transaction.before,after:copy(transaction.after)});future=[];setResearchStatus(r.id,'evidence','applied');saveLocal();render();toast('Evidence citation applied')}catch(e){toast('Could not apply proposal: '+e.message)}}
function applyResearchType(){const r=records[selected],p=researchProposals[r.id];if(!p?.suggestedType)return;const before=copy(r),next={...r,canonicalType:p.suggestedType.type,tags:[...new Set([...(r.tags||[]),...p.suggestedType.tags])]};const transaction=stageRecordReplacement(before,next);records[selected]=transaction.after;history.push({index:selected,before:transaction.before,after:copy(transaction.after)});future=[];setResearchStatus(r.id,'type','applied');saveLocal();render();toast('Suggested type applied — review before exporting')}
function applyResearchPeriod(){const r=records[selected],p=researchProposals[r.id];if(!p?.periodSuggestion)return;const before=copy(r),next={...r};if(p.periodSuggestion.periodStart!=null)next.periodStart=p.periodSuggestion.periodStart;if(p.periodSuggestion.periodEnd!=null)next.periodEnd=p.periodSuggestion.periodEnd;const transaction=stageRecordReplacement(before,next);records[selected]=transaction.after;history.push({index:selected,before:transaction.before,after:copy(transaction.after)});future=[];setResearchStatus(r.id,'period','applied');saveLocal();render();toast('Suggested period applied')}
// v0.6.7: REVIEW backlog decision support (scripts/review-signal-scanner.mjs). Unlike the
// research adapters, there is no single suggestion and no per-field applied/dismissed status to
// track — a REVIEW record can have several genuinely competing Type candidates by design, so the
// flag and the panel both key off live record state instead: the flag clears itself the moment
// either a Type gets applied (canonicalType is set) or the curator uses Scribe's existing
// ✓ REVIEWED marking (reviewStates) to say "I looked at this, nothing here to apply." No new
// decision-tracking map was added — both signals already exist for other reasons.
function recordHasPendingReviewCandidate(id){const p=reviewCandidates[id];if(!p||(!p.candidateCount&&!p.contentScopeFlag))return false;const r=records.find(x=>x.id===id);if(!r||r.canonicalType)return false;if(reviewStates[id]==='reviewed')return false;return true}
function loadReviewCandidates(file){const fr=new FileReader();fr.onload=()=>{try{const list=JSON.parse(fr.result);if(!Array.isArray(list))throw Error('Expected a JSON array of review candidates.');let added=0;for(const p of list){if(!p.recordId)continue;reviewCandidates[p.recordId]=p;added++}saveLocal();render();toast(`Loaded ${added} review candidate set(s) from ${file.name}`)}catch(e){toast('Could not load review candidates: '+e.message)}};fr.readAsText(file)}
function renderReviewPanel(){const r=records[selected],panel=$('#review-panel');if(!panel)return;const p=r&&reviewCandidates[r.id];if(!p){panel.classList.add('hidden');panel.innerHTML='';return}
  panel.classList.remove('hidden');
  let html=`<div class="proposal-card"><h4>🧭 Review candidates</h4>`;
  if(p.contentScopeFlag){html+=`<p class="proposal-status warning">⚠ Policy question, not a Type pick: ${esc(p.contentScopeFlag)}</p>`}
  if(!p.candidates.length){
    html+=`<p class="proposal-status">No text signals matched any candidate Type${p.contentScopeFlag?' — see the policy question above':'; this record likely needs a closer read from scratch'}.</p>`;
  } else {
    for(const c of p.candidates){
      const applied=r.canonicalType===c.type;
      html+=`<div class="proposal-field-list"><div class="audit-row"><b>Candidate</b><span>${esc(c.type)} (${esc(c.section)})</span></div>`;
      if(c.caution)html+=`<div class="audit-row"><b>Note</b><span>${esc(c.caution)}</span></div>`;
      if(c.matches&&c.matches.length)html+=`<div class="audit-row"><b>Text evidence</b><span>${c.matches.map(m=>`“${esc(m.keyword)}”${m.snippets&&m.snippets.length?': '+m.snippets.map(esc).join(' / '):''}`).join('<br>')}</span></div>`;
      html+=`</div><div class="proposal-actions"><button type="button" class="win-button compact primary" data-apply-review-type="${esc(c.type)}">${applied?'✓ APPLIED':'APPLY TYPE'}</button></div>`;
    }
  }
  html+='</div>';panel.innerHTML=html;
  panel.querySelectorAll('[data-apply-review-type]').forEach(btn=>btn.addEventListener('click',()=>applyReviewType(btn.dataset.applyReviewType)));
}
function applyReviewType(type){const r=records[selected];if(!r||r.canonicalType===type)return;const before=copy(r),next={...r,canonicalType:type};const transaction=stageRecordReplacement(before,next);records[selected]=transaction.after;history.push({index:selected,before:transaction.before,after:copy(transaction.after)});future=[];saveLocal();render();toast(`Type "${type}" applied — review tags before exporting`)}
function applyResearchPleiadesEvidence(){const r=records[selected],p=researchProposals[r.id];if(!p?.pleiadesEvidenceProposal)return;if((r.evidence||[]).some(x=>x.source===p.pleiadesEvidenceProposal.source)){setResearchStatus(r.id,'pleiadesEvidence','applied');saveLocal();render();return}const merged=[...(r.evidence||[]),{id:`evidence-pleiades-${p.pleiadesId||r.id}`,...p.pleiadesEvidenceProposal}];try{const transaction=stageAdvancedTransaction(r,'evidence',JSON.stringify(merged),{registries:registry});records[selected]=transaction.after;history.push({index:selected,before:transaction.before,after:copy(transaction.after)});future=[];setResearchStatus(r.id,'pleiadesEvidence','applied');saveLocal();render();toast('Pleiades evidence citation applied')}catch(e){toast('Could not apply proposal: '+e.message)}}

// v0.6.8: component/tag candidate review (scripts/component-tag-signal-scanner.mjs). Like the
// REVIEW panel, there's no per-field applied/dismissed status to track — "applied" is derived
// directly from whether the record's own tags/functions already contain the candidate value, so
// the flag and panel both stay correct even if a curator added the same tag by hand instead of
// clicking APPLY, or re-loads the same candidates file after already acting on some of them.
function componentCandidatesPending(r){const p=componentCandidates[r.id];if(!p)return false;const tagPending=(p.tagCandidates||[]).some(c=>!r.tags.includes(c.tag));const fnPending=(p.functionCandidates||[]).some(c=>!r.functions.includes(c.function));return tagPending||fnPending}
function recordHasPendingComponentCandidate(id){const r=records.find(x=>x.id===id);if(!r)return false;return componentCandidatesPending(r)}
function loadComponentCandidates(file){const fr=new FileReader();fr.onload=()=>{try{const list=JSON.parse(fr.result);if(!Array.isArray(list))throw Error('Expected a JSON array of component/tag candidates.');let added=0;for(const p of list){if(!p.recordId)continue;componentCandidates[p.recordId]=p;added++}saveLocal();render();toast(`Loaded ${added} component/tag candidate set(s) from ${file.name}`)}catch(e){toast('Could not load component/tag candidates: '+e.message)}};fr.readAsText(file)}
function renderComponentPanel(){const r=records[selected],panel=$('#component-panel');if(!panel)return;const p=r&&componentCandidates[r.id];if(!p){panel.classList.add('hidden');panel.innerHTML='';return}
  panel.classList.remove('hidden');
  // v0.7.0 (explicit user request): when a record has more than one still-pending tag or
  // function candidate, offer one button that loops applyComponentTag()/applyComponentFunction()
  // over every currently-pending candidate of that kind — each call still goes through the exact
  // same governed stageRecordReplacement path individually, this just saves the repeated clicks.
  const pendingTags=(p.tagCandidates||[]).filter(c=>!r.tags.includes(c.tag));
  const pendingFns=(p.functionCandidates||[]).filter(c=>!r.functions.includes(c.function));
  let html=`<div class="proposal-card"><h4>🏗 Component/tag candidates</h4>`;
  if(pendingTags.length>1||pendingFns.length>1){
    html+='<div class="proposal-actions">';
    if(pendingTags.length>1)html+='<button type="button" class="win-button compact primary" data-apply-all-tags>➕ APPLY ALL TAGS</button>';
    if(pendingFns.length>1)html+='<button type="button" class="win-button compact primary" data-apply-all-functions>➕ APPLY ALL FUNCTIONS</button>';
    html+='</div>';
  }
  if(!(p.tagCandidates||[]).length&&!(p.functionCandidates||[]).length){
    html+=`<p class="proposal-status">No component/tag text signals matched.</p>`;
  } else {
    for(const c of p.tagCandidates||[]){
      const applied=r.tags.includes(c.tag);
      html+=`<div class="proposal-field-list"><div class="audit-row"><b>Tag</b><span>${esc(c.tag)} (${esc(c.section)})</span></div>`;
      if(c.caution)html+=`<div class="audit-row"><b>Note</b><span>${esc(c.caution)}</span></div>`;
      if(c.matches?.length)html+=`<div class="audit-row"><b>Text evidence</b><span>${c.matches.map(m=>`“${esc(m.keyword)}”${m.snippets?.length?': '+m.snippets.map(esc).join(' / '):''}`).join('<br>')}</span></div>`;
      html+=`</div><div class="proposal-actions"><button type="button" class="win-button compact primary" data-apply-component-tag="${esc(c.tag)}" ${applied?'disabled':''}>${applied?'✓ APPLIED':'APPLY TAG'}</button></div>`;
    }
    for(const c of p.functionCandidates||[]){
      const applied=r.functions.includes(c.function);
      html+=`<div class="proposal-field-list"><div class="audit-row"><b>Function</b><span>${esc(c.function)} (${esc(c.section)})</span></div>`;
      if(c.matches?.length)html+=`<div class="audit-row"><b>Text evidence</b><span>${c.matches.map(m=>`“${esc(m.keyword)}”${m.snippets?.length?': '+m.snippets.map(esc).join(' / '):''}`).join('<br>')}</span></div>`;
      html+=`</div><div class="proposal-actions"><button type="button" class="win-button compact primary" data-apply-component-function="${esc(c.function)}" ${applied?'disabled':''}>${applied?'✓ APPLIED':'APPLY FUNCTION'}</button></div>`;
    }
  }
  html+='</div>';panel.innerHTML=html;
  panel.querySelectorAll('[data-apply-component-tag]').forEach(btn=>btn.addEventListener('click',()=>applyComponentTag(btn.dataset.applyComponentTag)));
  panel.querySelectorAll('[data-apply-component-function]').forEach(btn=>btn.addEventListener('click',()=>applyComponentFunction(btn.dataset.applyComponentFunction)));
  panel.querySelector('[data-apply-all-tags]')?.addEventListener('click',()=>{for(const c of pendingTags)applyComponentTag(c.tag)});
  panel.querySelector('[data-apply-all-functions]')?.addEventListener('click',()=>{for(const c of pendingFns)applyComponentFunction(c.function)});
}
function applyComponentTag(tag){const r=records[selected];if(!r||r.tags.includes(tag))return;const before=copy(r),next={...r,tags:[...new Set([...(r.tags||[]),tag])]};const transaction=stageRecordReplacement(before,next);records[selected]=transaction.after;history.push({index:selected,before:transaction.before,after:copy(transaction.after)});future=[];saveLocal();render();toast(`Tag "${tag}" applied`)}
function applyComponentFunction(fn){const r=records[selected];if(!r||r.functions.includes(fn))return;const before=copy(r),next={...r,functions:[...new Set([...(r.functions||[]),fn])]};const transaction=stageRecordReplacement(before,next);records[selected]=transaction.after;history.push({index:selected,before:transaction.before,after:copy(transaction.after)});future=[];saveLocal();render();toast(`Function "${fn}" applied`)}

// v0.6.8: phase/chronology candidate review (scripts/phase-chronology-signal-scanner.mjs).
// "Applied" is derived the same way as the component/tag panel above — a candidate counts as
// applied when the record's own phases[] already has an entry with the same type/start/end,
// whether that came from clicking APPLY here or was typed by hand in the phases editor.
function phaseCandidatesPending(r){const p=phaseCandidates[r.id];if(!p)return false;return(p.candidates||[]).some(c=>!(r.phases||[]).some(ph=>ph.type===c.type&&Number(ph.start)===c.start&&Number(ph.end)===c.end))}
function recordHasPendingPhaseCandidate(id){const r=records.find(x=>x.id===id);if(!r)return false;return phaseCandidatesPending(r)}
function loadPhaseCandidates(file){const fr=new FileReader();fr.onload=()=>{try{const list=JSON.parse(fr.result);if(!Array.isArray(list))throw Error('Expected a JSON array of phase candidates.');let added=0;for(const p of list){if(!p.recordId)continue;phaseCandidates[p.recordId]=p;added++}saveLocal();render();toast(`Loaded ${added} phase candidate set(s) from ${file.name}`)}catch(e){toast('Could not load phase candidates: '+e.message)}};fr.readAsText(file)}
function renderPhasePanel(){const r=records[selected],panel=$('#phase-panel');if(!panel)return;const p=r&&phaseCandidates[r.id];if(!p){panel.classList.add('hidden');panel.innerHTML='';return}
  panel.classList.remove('hidden');
  let html=`<div class="proposal-card"><h4>📅 Phase/chronology candidates</h4>`;
  if(!(p.candidates||[]).length){
    html+=`<p class="proposal-status">No phase text signals matched.</p>`;
  } else {
    p.candidates.forEach((c,idx)=>{
      const applied=(r.phases||[]).some(ph=>ph.type===c.type&&Number(ph.start)===c.start&&Number(ph.end)===c.end);
      html+=`<div class="proposal-field-list"><div class="audit-row"><b>Phase</b><span>${esc(c.label)} (${esc(c.section)})</span></div><div class="audit-row"><b>Start → End</b><span>${esc(c.start)} → ${esc(c.end)}${c.assumedEra?' <em>(century with no BC/AD marker — assumed CE, verify)</em>':''}</span></div><div class="audit-row"><b>Text evidence</b><span>“${esc(c.matchedKeyword)}” / ${esc(c.matchedDate)}: ${esc(c.evidence)}</span></div></div><div class="proposal-actions"><button type="button" class="win-button compact primary" data-apply-phase="${idx}" ${applied?'disabled':''}>${applied?'✓ APPLIED':'APPLY PHASE'}</button></div>`;
    });
  }
  html+='</div>';panel.innerHTML=html;
  panel.querySelectorAll('[data-apply-phase]').forEach(btn=>btn.addEventListener('click',()=>applyPhaseCandidate(+btn.dataset.applyPhase)));
}
function applyPhaseCandidate(idx){const r=records[selected],p=phaseCandidates[r.id],c=p?.candidates?.[idx];if(!c)return;const applied=(r.phases||[]).some(ph=>ph.type===c.type&&Number(ph.start)===c.start&&Number(ph.end)===c.end);if(applied)return;const before=copy(r),newPhase={id:`phase-scan-${(r.phases||[]).length+1}`,label:c.label,type:c.type,start:c.start,end:c.end,chronologyIds:[]},next={...r,phases:[...(r.phases||[]),newPhase]};const transaction=stageRecordReplacement(before,next);records[selected]=transaction.after;history.push({index:selected,before:transaction.before,after:copy(transaction.after)});future=[];saveLocal();render();toast(`Phase "${c.label}" applied — review before exporting`)}

// v0.6.0: new-site proposal review (second adapter slice: scripts/unesco-newsite-adapter.mjs
// proposes entirely new records, not enrichments to an existing one). Unlike the enrichment
// proposals above, a pending new-site candidate is deliberately kept OUT of records[]
// entirely — it lives only in newSiteProposals/newSiteStatus — so loading a proposals file
// can never by itself change what a "records: N" count or an export contains. Only ACCEPT
// splices a candidate into records/original/sourceRecords, at which point it's a completely
// normal record (editable, exportable, subject to the same validation as anything else).
// v0.6.2: keyed by proposalId (per PHYSICAL COMPONENT — "352-c1", "352-c2", …), not by
// unescoId (per UNESCO PROPERTY). A serial property proposes one candidate per component
// (see the adapter's header comment — the "Rock Art of Alta" case is why), so more than
// one pending/accepted proposal can legitimately share the same unescoId; keying by
// property would make accepting one component hide its siblings as if resolved too.
function loadNewSiteProposals(file){const fr=new FileReader();fr.onload=()=>{try{const list=JSON.parse(fr.result);if(!Array.isArray(list))throw Error('Expected a JSON array of proposals.');const existingIds=new Set(records.map(r=>r.id));let added=0,skippedExisting=0;for(const p of list){if(!p.proposalId||!p.candidate)continue;if(existingIds.has(p.candidate.id)){skippedExisting++;continue}newSiteProposals[p.proposalId]=p;if(!newSiteStatus[p.proposalId])newSiteStatus[p.proposalId]='pending';added++}saveLocal();render();toast(`Loaded ${added} new-site proposal(s) from ${file.name}${skippedExisting?` (${skippedExisting} already in your catalogue, skipped)`:''}`)}catch(e){toast('Could not load new-site proposals: '+e.message)}};fr.readAsText(file)}

function newSiteFiltered(status='pending'){const q=($('#newsite-search')?.value||'').trim().toLowerCase(),cat=$('#newsite-category-filter')?.value||'all';return Object.values(newSiteProposals).filter(p=>newSiteStatus[p.proposalId]===status&&(cat==='all'||p.category===cat)&&(!q||p.officialName.toLowerCase().includes(q)||(p.candidate.name||'').toLowerCase().includes(q)))}
// v0.7.0: real "why" line from the candidate's own description field (never fabricated —
// truncated client-side only, the text itself is exactly what the adapter proposed).
function newSiteWhyHTML(p){const d=p.candidate.description;if(!d)return'';const text=d.length>220?d.slice(0,220)+'…':d;return`<span class="why">${esc(text)}</span>`}
function newSiteRowHTML(p){const partOf=p.componentName&&p.componentName!==p.officialName?` · part of “${esc(p.officialName)}”${p.candidate.heritage.unesco.componentIndex?` (${p.candidate.heritage.unesco.componentIndex}/${p.candidate.heritage.unesco.componentsCount})`:''}`:'';return`<div class="newsite-row" data-proposal-id="${esc(p.proposalId)}"><span class="newsite-name">${esc(p.candidate.name)}</span><span class="newsite-meta">${esc(p.category||'—')} · ${p.candidate.latitude.toFixed(3)}, ${p.candidate.longitude.toFixed(3)}${p.dangerListed?' · ⚠ danger-listed':''}${partOf} — <a href="${esc(p.sourceUrl)}" target="_blank" rel="noopener">listing</a></span>${newSiteWhyHTML(p)}<div class="newsite-actions"><button type="button" class="win-button compact primary" data-accept-newsite="${esc(p.proposalId)}">ACCEPT</button><button type="button" class="win-button compact" data-reject-newsite="${esc(p.proposalId)}">REJECT</button></div></div>`}
// Groups consecutive rows that share a unescoId into one collapsible block with its own
// ACCEPT ALL / REJECT ALL. Adjacency holds because every component of one UNESCO property
// is inserted together, in components_list order, by loadNewSiteProposals — the only
// proposalIds that could get reordered ahead of others by JS's integer-key ordering are
// bare unescoIds (single-component fallback candidates), and those never have siblings to
// group with. A property only gets a header when more than one of its components is both
// still pending and passing the current search/category filter — the batch buttons act on
// exactly that filtered set, same as ACCEPT ALL FILTERED / REJECT ALL FILTERED do for the
// whole list, so "what you see is what a click resolves" holds at both granularities.
function newSiteGroupHTML(pending){const groups=[];for(const p of pending){const last=groups[groups.length-1];if(last&&last.unescoId===p.unescoId)last.items.push(p);else groups.push({unescoId:p.unescoId,officialName:p.officialName,items:[p]})}return groups.map(g=>{const rows=g.items.map(newSiteRowHTML).join('');if(g.items.length<2)return rows;return `<div class="newsite-group"><div class="newsite-group-header"><span>${esc(g.officialName)} — ${g.items.length} component(s) pending</span><div class="newsite-actions"><button type="button" class="win-button compact primary" data-accept-property="${esc(g.unescoId)}">ACCEPT ALL</button><button type="button" class="win-button compact" data-reject-property="${esc(g.unescoId)}">REJECT ALL</button></div></div>${rows}</div>`}).join('')}
// v0.7.0 perf fix: with the real 5,192-candidate UNESCO file loaded and no search/category
// filter applied, this used to build full HTML for every pending row on every render — real,
// reported multi-second lag. NEWSITE_RENDER_CAP shows the first N (search/category narrows this
// same way it always did; batch actions below still act on the FULL filtered set, never just
// what's rendered) with an explicit overflow note.
const NEWSITE_RENDER_CAP=150;
function renderNewSites(){if(currentStage!=='newsites')return;const pending=newSiteFiltered('pending'),accepted=newSiteFiltered('accepted'),total=Object.keys(newSiteProposals).length,properties=new Set(Object.values(newSiteProposals).map(p=>p.unescoId)).size;$('#newsite-summary').textContent=total?`${pending.length} pending of ${total} loaded across ${properties} UNESCO propert${properties===1?'y':'ies'} (${accepted.length} accepted, in your catalogue).`:'No proposals loaded.';$('#newsite-filtered-count').textContent=pending.length?`${pending.length} match current filter`:'';$('#accept-all-filtered').disabled=!pending.length;$('#reject-all-filtered').disabled=!pending.length;$('#newsite-list').innerHTML=(newSiteGroupHTML(pending.slice(0,NEWSITE_RENDER_CAP))||'<div class="empty-phases">No pending proposals match this filter.</div>')+(pending.length>NEWSITE_RENDER_CAP?`<p class="proposal-status">Showing the first ${NEWSITE_RENDER_CAP} of ${pending.length} — narrow with search/category to see others (batch actions still act on all ${pending.length}).</p>`:'');$('#newsite-accepted-list').innerHTML=accepted.map(p=>`<div class="newsite-row" data-proposal-id="${esc(p.proposalId)}"><span class="newsite-name">${esc(p.candidate.name)}</span><div class="newsite-actions"><button type="button" class="win-button compact" data-remove-newsite="${esc(p.proposalId)}">REMOVE (UNDO ADD)</button></div></div>`).join('')||'<div class="empty-phases">None accepted yet.</div>';$$('[data-accept-newsite]').forEach(b=>b.onclick=()=>acceptNewSite(b.dataset.acceptNewsite));$$('[data-reject-newsite]').forEach(b=>b.onclick=()=>rejectNewSite(b.dataset.rejectNewsite));$$('[data-remove-newsite]').forEach(b=>b.onclick=()=>removeAcceptedNewSite(b.dataset.removeNewsite));$$('[data-accept-property]').forEach(b=>b.onclick=()=>acceptAllForProperty(b.dataset.acceptProperty));$$('[data-reject-property]').forEach(b=>b.onclick=()=>rejectAllForProperty(b.dataset.rejectProperty));
  // v0.7.0: clicking a proposal row (not one of its buttons) focuses the minimap on that
  // candidate's coordinates without touching the catalogue's own `selected` record — see
  // focusOn()/renderMap() below.
  $$('#newsite-list .newsite-row[data-proposal-id]').forEach(row=>{row.onclick=e=>{if(e.target.closest('button'))return;const p=newSiteProposals[row.dataset.proposalId];if(p)focusOn(+p.candidate.latitude,+p.candidate.longitude,p.candidate.name)}})
}
// The single governed path that turns a pending candidate into a real catalogue record.
// Every accept action — one click, a filtered batch, or a whole property's batch — funnels
// through this one function, so `records.push` needs to appear exactly once in this file
// no matter how many ways there are to trigger an accept.
function acceptCandidate(proposalId){const p=newSiteProposals[proposalId];if(!p)return null;const rec=copy(p.candidate);records.push(rec);original.push(copy(rec));sourceRecords.push(null);newSiteStatus[proposalId]='accepted';return records.length-1}
function acceptNewSite(proposalId){const p=newSiteProposals[proposalId];const idx=acceptCandidate(proposalId);if(idx===null)return;saveLocal();select(idx);toast(`Added “${p.candidate.name}” — set its type and review before exporting.`)}
function rejectNewSite(proposalId){const p=newSiteProposals[proposalId];if(!p)return;newSiteStatus[proposalId]='rejected';saveLocal();render();toast(`Dismissed “${p.candidate.name}”`)}
// v0.7.2 (bug 1): every mutator in this file pushes {index, before, after} onto history/future
// using a plain numeric index into records[], and removeAcceptedNewSite() below is the ONLY place
// that ever SHRINKS those arrays (everything else replaces an element in place). Nothing used to
// fix up the indices already parked in history/future when that splice happened, so an undo could
// write `before` back at a stale index — one past the shrunk array's end, or worse, on top of a
// different record that had shifted down into it — desyncing records[] from original[]/
// sourceRecords[] and crashing renderDistance() on the next render. Called from the splice site
// below, on BOTH arrays: an entry AT idx refers to the record that just left the catalogue and can
// no longer be applied to anything, so it is dropped; an entry ABOVE idx is decremented to keep
// pointing at the same logical record; an entry BELOW idx is untouched.
function reindexHistoryAfterSplice(idx){const fix=a=>{for(let k=a.length-1;k>=0;k--){const e=a[k];if(e.index===idx)a.splice(k,1);else if(e.index>idx)e.index--}};fix(history);fix(future)}
function removeAcceptedNewSite(proposalId){const p=newSiteProposals[proposalId];if(!p)return;const idx=records.findIndex(r=>r.id===p.candidate.id);if(idx<0)return;records.splice(idx,1);original.splice(idx,1);sourceRecords.splice(idx,1);reindexHistoryAfterSplice(idx);newSiteStatus[proposalId]='pending';if(selected>idx)selected--;else if(selected===idx)selected=Math.max(0,idx-1);selected=Math.min(selected,records.length-1);saveLocal();render();toast('Removed — back in the pending list')}
// Batch accept/reject. acceptAllFiltered/rejectAllFiltered act on every pending proposal
// currently passing the search + category filter — "accept everything Cultural", "reject
// everything that matched this search". acceptAllForProperty/rejectAllForProperty act on
// every still-pending, currently-filtered component of one property — "accept every
// component of this property I've decided on" — regardless of how many total components it
// has, so resolving one property doesn't require clearing the search/category filter first.
function acceptAllForList(list,label){if(!list.length){toast('No pending proposals match this filter.');return}let firstIdx=null;for(const p of list){const idx=acceptCandidate(p.proposalId);if(firstIdx===null)firstIdx=idx}saveLocal();select(firstIdx);toast(`Accepted ${list.length} proposal(s)${label?` from “${label}”`:''} — review and set types before exporting.`)}
function rejectAllForList(list,label){if(!list.length){toast('No pending proposals match this filter.');return}for(const p of list)newSiteStatus[p.proposalId]='rejected';saveLocal();render();toast(`Dismissed ${list.length} proposal(s)${label?` from “${label}”`:''}`)}
function acceptAllFiltered(){acceptAllForList(newSiteFiltered('pending'))}
function rejectAllFiltered(){rejectAllForList(newSiteFiltered('pending'))}
function acceptAllForProperty(unescoId){const list=Object.values(newSiteProposals).filter(p=>p.unescoId===unescoId&&newSiteStatus[p.proposalId]==='pending');acceptAllForList(list,list[0]?.officialName)}
function rejectAllForProperty(unescoId){const list=Object.values(newSiteProposals).filter(p=>p.unescoId===unescoId&&newSiteStatus[p.proposalId]==='pending');rejectAllForList(list,list[0]?.officialName)}

function advancedDefault(field){return['heritage','workflow','provenance','dataQuality'].includes(field)?{}:[]}
function renderAdvanced(){const value=records[selected]?.[advancedDimension]??advancedDefault(advancedDimension);$('#advanced-dimension').value=advancedDimension;$('#advanced-json').value=JSON.stringify(value,null,2);const count=Array.isArray(value)?`${value.length} entr${value.length===1?'y':'ies'}`:(value&&typeof value==='object'?`${Object.keys(value).length} top-level fields`:'empty');$('#advanced-status').className='advanced-status';$('#advanced-status').textContent=`${advancedDimension}: ${count}. No change is staged until VALIDATE + STAGE is pressed.`}
function parseAdvanced(){return parseAdvancedDocument(advancedDimension,$('#advanced-json').value,{registries:registry,record:records[selected]})}
function applyAdvanced(){try{const transaction=stageAdvancedTransaction(records[selected],advancedDimension,$('#advanced-json').value,{registries:registry}),before=transaction.before;records[selected]=transaction.after;history.push({index:selected,before,after:copy(transaction.after)});future=[];saveLocal();render();$('#advanced-status').className='advanced-status ok';$('#advanced-status').textContent=transaction.findings.length?`${advancedDimension} staged with ${transaction.findings.length} preserved review warning(s).`:`${advancedDimension} is valid and has been staged as one transaction.`;toast(`${advancedDimension} staged`)}catch(e){$('#advanced-status').className='advanced-status error';$('#advanced-status').textContent=e.message}}
function formatAdvanced(){try{const parsed=parseAdvanced();$('#advanced-json').value=JSON.stringify(parsed.value,null,2);$('#advanced-status').className='advanced-status ok';$('#advanced-status').textContent=parsed.findings.length?`Structurally valid with ${parsed.findings.length} preserved review warning(s). Press VALIDATE + STAGE to apply it.`:'JSON is structurally valid. Press VALIDATE + STAGE to apply it.'}catch(e){$('#advanced-status').className='advanced-status error';$('#advanced-status').textContent=e.message}}

function renderReview(){$$('[data-review]').forEach(b=>b.classList.toggle('active',b.dataset.review===review(selected)))}function setReview(s){reviewStates[records[selected].id]=reviewStates[records[selected].id]===s?'unreviewed':s;saveLocal();render()}
function diff(i){return[...new Set([...Object.keys(original[i]||{}),...Object.keys(records[i]||{})])].filter(k=>JSON.stringify(records[i][k])!==JSON.stringify(original[i]?.[k]))}
const format=v=>v===undefined?'—':typeof v==='object'?JSON.stringify(v):String(v);
function renderChanges(){const a=diff(selected);$('#record-changes').innerHTML=a.map(k=>`<div class="change-row"><b>${esc(k)}</b><code>${esc(format(original[selected]?.[k]))} → ${esc(format(records[selected]?.[k]))}</code><button class="win-button compact" data-revert-field="${esc(k)}">REVERT</button></div>`).join('')||'No staged fields changed.';$$('[data-revert-field]').forEach(b=>b.onclick=()=>{const before=copy(records[selected]),k=b.dataset.revertField;if(k in original[selected])records[selected][k]=copy(original[selected][k]);else delete records[selected][k];history.push({index:selected,before,after:copy(records[selected])});future=[];saveLocal();render()})}
function undo(){const o=history.pop();if(!o)return;future.push(o);records[o.index]=copy(o.before);selected=o.index;saveLocal();render()}function redo(){const o=future.pop();if(!o)return;history.push(o);records[o.index]=copy(o.after);selected=o.index;saveLocal();render()}function revert(){if(!confirm('Revert every staged change to this record?'))return;const before=copy(records[selected]);records[selected]=copy(original[selected]);history.push({index:selected,before,after:copy(records[selected])});future=[];saveLocal();render()}
// v0.7.0: staged, reversible removal (Editor stage). Never an actual delete — the record stays
// in records[]/autosave/undo history exactly like any other record (still visible via the
// `removal` issue-filter, still fully editable) and only the two Export Centre file downloads
// skip it (see the #download-canonical/#download-dataset handlers and lossReport() below,
// which both explicitly surface the exclusion rather than hiding it). Goes through the same
// governed stageAdvancedTransaction('workflow', …) path as every other workflow write.
function toggleRemoval(){const r=records[selected];if(!r)return;const has=!!r.workflow?.pendingRemoval,merged={...(r.workflow||{})};if(has)delete merged.pendingRemoval;else merged.pendingRemoval={at:new Date().toISOString(),reason:'manual'};try{const transaction=stageAdvancedTransaction(r,'workflow',JSON.stringify(merged),{registries:registry});records[selected]=transaction.after;history.push({index:selected,before:transaction.before,after:copy(transaction.after)});future=[];saveLocal();render();toast(has?'Restored — no longer marked for removal':'Marked for removal — excluded from exports, still visible and restorable here')}catch(e){toast('Could not update removal state: '+e.message)}}
function validateCanonicalLinks(r){return validateCoreLinks(r)}
function renderValidation(){const a=[...validate(records[selected],selected),...validateCanonicalLinks(records[selected])],errors=a.filter(x=>x[0]==='error').length,warnings=a.filter(x=>x[0]==='warning').length;$('#validation-summary').textContent=a.length?`${errors} errors · ${warnings} warnings · ${a.length-errors-warnings} notices`:'Record passes canonical checks.';$('#validation-list').innerHTML=a.map(([l,m])=>`<li class="${l}">${esc(m)}</li>`).join('')}
function renderPreview(){const r=records[selected],v=previewMode==='canonical'?canonical(r):previewMode==='legacy'?projection(r,selected):losses(r,selected).map(([severity,field,message])=>({severity,field,message}));$('#projection-preview').textContent=JSON.stringify(v,null,2);$$('[data-preview]').forEach(b=>b.classList.toggle('active',b.dataset.preview===previewMode))}

function lonX(l,z){return(l+180)/360*256*2**z}function latY(l,z){const s=Math.sin(l*Math.PI/180);return(.5-Math.log((1+s)/(1-s))/(4*Math.PI))*256*2**z}function xLon(x,z){return x/(256*2**z)*360-180}function yLat(y,z){const n=Math.PI-2*Math.PI*y/(256*2**z);return 180/Math.PI*Math.atan(Math.sinh(n))}
// v0.7.0: the minimap now has two "centers" it can show. Normally (Enrichment/Editor) it
// centers on the selected catalogue record, exactly as before. On New Sites/Scraping/Curator,
// clicking a proposal/candidate row calls focusOn() to center the map on THAT item's real
// coordinates instead — without touching `selected`, since those rows are not existing
// catalogue records. Leaving back to Enrichment/Editor clears focusCoords (see switchStage()).
function focusOn(lat,lon,label){if(!Number.isFinite(lat)||!Number.isFinite(lon))return;focusCoords={lat,lon,label};renderMap()}
// Real, computed-from-the-loaded-catalogue "nearby markers" overlay: brute-force haversine
// distance (2,103 records is small — fine to scan every render) against every OTHER record,
// projected with the exact same lonX/latY tile math the imagery tiles use, so the dots line up
// with the actual imagery under them.
function nearbyMarkers(lat,lon,excludeIndex){const out=[];records.forEach((r,i)=>{if(i===excludeIndex)return;const rl=+r.latitude,rn=+r.longitude;if(!Number.isFinite(rl)||!Number.isFinite(rn))return;const d=haversineKm(lat,lon,rl,rn);if(d<=NEARBY_RADIUS_KM)out.push({r,i,d})});return out.sort((a,b)=>a.d-b.d)}
// v0.7.1: tile-rendering pulled out of renderMap() into its own helper, purely so the Curator
// compare split-pane (feature 2) can render the exact same tile math into either of its two
// panes without a second hand-copied loop to keep in sync — renderMap()'s own single-map
// behavior below is otherwise unchanged.
function tileLayerHTML(lat,lon,zoom,w,h){const cx=lonX(lon,zoom),cy=latY(lat,zoom),minX=Math.floor((cx-w/2)/256),maxX=Math.floor((cx+w/2)/256),minY=Math.floor((cy-h/2)/256),maxY=Math.floor((cy+h/2)/256);let html='';for(let x=minX;x<=maxX;x++)for(let y=minY;y<=maxY;y++)html+=`<img class="map-tile" draggable="false" src="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${zoom}/${y}/${x}" style="left:${x*256-(cx-w/2)}px;top:${y*256-(cy-h/2)}px" alt="">`;return{html,cx,cy}}
function renderMap(){if(compareMode)return renderCompareMap();const r=records[selected],map=$('#satellite-map');const center=focusCoords||(r&&Number.isFinite(+r.latitude)&&Number.isFinite(+r.longitude)?{lat:+r.latitude,lon:+r.longitude,label:r.name}:null);if(!center){$('#tile-layer').innerHTML='';$('#map-nearby-layer').innerHTML='';$('#map-nearby-caption').textContent='';return}
  const w=map.clientWidth||280,h=map.clientHeight||210,{html,cx,cy}=tileLayerHTML(center.lat,center.lon,mapZoom,w,h);
  $('#tile-layer').innerHTML=html;
  $('#map-coords').textContent=`${center.lat.toFixed(5)}, ${center.lon.toFixed(5)} · z${mapZoom}${focusCoords?' · '+esc(focusCoords.label):''}`;
  const excludeIndex=focusCoords?-1:selected;
  const nearby=nearbyMarkers(center.lat,center.lon,excludeIndex);
  $('#map-nearby-layer').innerHTML=nearby.map(({r:nr,d})=>{const px=lonX(+nr.longitude,mapZoom)-(cx-w/2),py=latY(+nr.latitude,mapZoom)-(cy-h/2);return`<div class="map-nearby-dot" style="left:${px}px;top:${py}px" title="${esc(nr.name)} · ${d.toFixed(2)}km"></div>`}).join('');
  $('#map-nearby-caption').textContent=nearby.length?`${nearby.length} nearby marker${nearby.length===1?'':'s'} within ${NEARBY_RADIUS_KM}km`:`No nearby markers within ${NEARBY_RADIUS_KM}km`;
  positionCoordMarker();
}
// v0.7.1: Curator compare split-pane (feature 2) — renders compareState.existing/.candidate
// into the two static #map-compare-tiles-*/#map-compare-coords-*/#map-compare-label-*
// elements in index.html via the same tileLayerHTML() helper renderMap() uses, sharing one
// mapZoom (see the compareMode/compareState declaration above for why).
function renderCompareMap(){if(!compareState)return;['existing','candidate'].forEach(side=>{const c=compareState[side];if(!c)return;const tileEl=$(`#map-compare-tiles-${side}`),coordsEl=$(`#map-compare-coords-${side}`),labelEl=$(`#map-compare-label-${side}`);if(!tileEl)return;const paneMap=tileEl.closest('.map-compare-canvas'),w=paneMap?.clientWidth||220,h=paneMap?.clientHeight||160;const{html}=tileLayerHTML(c.lat,c.lon,mapZoom,w,h);tileEl.innerHTML=html;if(coordsEl)coordsEl.textContent=`${c.lat.toFixed(5)}, ${c.lon.toFixed(5)} · z${mapZoom}`;if(labelEl)labelEl.textContent=c.label||''})}
function enterCompareMode(existing,candidate){cancelCoordEdit(true);compareState={existing,candidate};compareMode=true;$('#satellite-map').classList.add('hidden');$('.map-toolbar').classList.add('hidden');$('.map-help').classList.add('hidden');$('#map-nearby-caption').classList.add('hidden');$('#map-compare-wrap').classList.remove('hidden');renderMap()}
function exitCompareMode(){compareMode=false;compareState=null;$('#map-compare-wrap').classList.add('hidden');$('#satellite-map').classList.remove('hidden');$('.map-toolbar').classList.remove('hidden');$('.map-help').classList.remove('hidden');$('#map-nearby-caption').classList.remove('hidden');renderMap()}
// v0.7.1: mousewheel zoom (feature 3) — shared by the single map and both compare panes;
// same clamp (2-19) the existing #zoom-in/#zoom-out buttons already use.
function onMapWheel(e){e.preventDefault();mapZoom=e.deltaY<0?Math.min(19,mapZoom+1):Math.max(2,mapZoom-1);renderMap()}
// v0.7.2: EDIT COORDINATES (feature 2). Until now ANY click anywhere on the imagery instantly
// moved the selected record's coordinates and commit()ed them — no mode, no drag, no confirmation.
// That is now gated behind an explicit edit mode: outside it the map is look-only (exactly how it
// already behaved during Curator/focus/compare), and inside it a click or a marker drag only moves
// a PENDING position. Nothing is staged until SAVE, which runs the same commit() →
// stageRecordReplacement() path every other field edit uses; CANCEL throws the pending position
// away and snaps the marker back to the saved one.
// Only ever available for the SELECTED catalogue record on Enrichment/Editor — never inside
// Curator's compare split-pane or while a New Sites/Scraping/Curator focusCoords is showing, since
// none of those are editing a catalogue record's own coordinates.
function coordEditAvailable(){return!!records[selected]&&!focusCoords&&!compareMode&&(currentStage==='enrichment'||currentStage==='editor')}
function mapCenterCoords(){const r=records[selected];return r&&Number.isFinite(+r.latitude)&&Number.isFinite(+r.longitude)?{lat:+r.latitude,lon:+r.longitude}:null}
function coordFromPointer(clientX,clientY){const map=$('#satellite-map'),c=mapCenterCoords();if(!map||!c)return null;const b=map.getBoundingClientRect(),cx=lonX(c.lon,mapZoom),cy=latY(c.lat,mapZoom);return{lat:+yLat(cy+clientY-b.top-b.height/2,mapZoom).toFixed(6),lon:+xLon(cx+clientX-b.left-b.width/2,mapZoom).toFixed(6)}}
// The pending marker is positioned with the exact same lonX/latY tile math the imagery and the
// nearby dots use, so it sits on the real place under it. The fixed .map-crosshair keeps marking
// the LAST SAVED position, which is what makes "where it will go" visually distinct from "where it
// is" before SAVE is pressed.
function positionCoordMarker(){const m=$('#coord-edit-marker'),map=$('#satellite-map');if(!m)return;const c=mapCenterCoords();if(!coordEdit||!coordPending||compareMode||focusCoords||!c||!map){m.classList.add('hidden');return}const w=map.clientWidth||280,h=map.clientHeight||210,cx=lonX(c.lon,mapZoom),cy=latY(c.lat,mapZoom);m.style.left=(lonX(coordPending.lon,mapZoom)-(cx-w/2))+'px';m.style.top=(latY(coordPending.lat,mapZoom)-(cy-h/2))+'px';m.classList.remove('hidden')}
function renderCoordEdit(){const btn=$('#edit-coordinates');if(!btn)return;btn.classList.toggle('active',coordEdit);btn.disabled=!coordEdit&&!coordEditAvailable();$('#coord-edit-bar')?.classList.toggle('hidden',!coordEdit);$('#satellite-map')?.classList.toggle('coord-editing',coordEdit);
  // #restore-coordinates is disabled while an uncommitted pending position exists — "revert to the
  // original coordinates" and "I'm halfway through placing a new one" are contradictory, and the
  // pending marker would silently survive the revert. #copy-coordinates stays enabled: it only
  // reads the form fields, which SAVE hasn't touched yet.
  const restore=$('#restore-coordinates');if(restore)restore.disabled=coordEdit;
  const p=$('#coord-edit-pending');if(!p)return;const c=mapCenterCoords();
  if(coordEdit&&coordPending&&c){const d=hav(c.lat,c.lon,coordPending.lat,coordPending.lon);p.textContent=`Pending ${coordPending.lat.toFixed(5)}, ${coordPending.lon.toFixed(5)} · ${d>.0005?(d<1?Math.round(d*1000)+' m':d.toFixed(2)+' km')+' from saved':'unmoved'}`}
  else p.textContent='—';
  positionCoordMarker()}
function enterCoordEdit(){if(coordEdit)return;if(!coordEditAvailable()){toast('Select a catalogue record on the Enrichment or Editor stage first');return}const c=mapCenterCoords();if(!c){toast('This record has no usable coordinates to move');return}coordEdit=true;coordPending={...c};renderCoordEdit();renderMap();toast('Edit mode — drag the yellow marker, then SAVE or CANCEL')}
function cancelCoordEdit(quiet){const was=coordEdit;coordEdit=false;coordPending=null;coordDragging=false;$('#coord-edit-marker')?.classList.remove('dragging');renderCoordEdit();renderMap();if(was&&!quiet)toast('Coordinate edit cancelled — marker back at the saved position')}
function saveCoordEdit(){if(!coordEdit||!coordPending)return;const p=coordPending;coordEdit=false;coordPending=null;coordDragging=false;$('[name=latitude]').value=p.lat.toFixed(6);$('[name=longitude]').value=p.lon.toFixed(6);commit();renderCoordEdit();renderMap();toast('Coordinates staged')}
function moveCoordinates(e){if(!coordEdit||focusCoords||compareMode)return;const p=coordFromPointer(e.clientX,e.clientY);if(!p)return;coordPending=p;renderCoordEdit()}
function hav(a,b,c,d){const R=6371,p=Math.PI/180,x=(c-a)*p,y=(d-b)*p,q=Math.sin(x/2)**2+Math.cos(a*p)*Math.cos(c*p)*Math.sin(y/2)**2;return 2*R*Math.asin(Math.sqrt(q))}function renderDistance(){const r=records[selected],o=original[selected],km=hav(+o.latitude,+o.longitude,+r.latitude,+r.longitude);$('#coordinate-distance').textContent=km>.001?`Moved ${km<1?Math.round(km*1000)+' m':km.toFixed(2)+' km'}`:''}

// v0.5.5: the full catalogue (2,103 records) autosaved as four independent full
// copies (sourceRecords+records+original+exportedCheckpoint) serializes to ~18.5MB,
// which exceeds every browser's localStorage quota (this build's Chromium fails
// anywhere above ~5MB) and made "Open Dataset" on the full catalogue throw
// QuotaExceededError on the very first autosave. IndexedDB has no comparable limit
// (it's disk-quota-based, effectively unbounded for a catalogue this size), so the
// autosave now lives there instead. The stored shape is unchanged — same four
// arrays, same restore semantics — only the storage backend moved.
const IDB_NAME='scribe98-v05',IDB_STORE='session',IDB_KEY='current';
let idbConnection=null;
function idbOpen(){if(!idbConnection)idbConnection=new Promise((resolve,reject)=>{const req=indexedDB.open(IDB_NAME,1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains(IDB_STORE))req.result.createObjectStore(IDB_STORE)};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)});return idbConnection}
async function idbSet(key,value){const db=await idbOpen();return new Promise((resolve,reject)=>{const tx=db.transaction(IDB_STORE,'readwrite');tx.objectStore(IDB_STORE).put(value,key);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)})}
async function idbGet(key){const db=await idbOpen();return new Promise((resolve,reject)=>{const tx=db.transaction(IDB_STORE,'readonly');const req=tx.objectStore(IDB_STORE).get(key);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
async function saveLocal(){markCuratorDirty();try{await idbSet(IDB_KEY,{sourceRecords,records,original,exportedCheckpoint,filename,datasetShape,reviewStates,mode,fixtureId,unescoProposals,proposalDecisions,newSiteProposals,newSiteStatus,researchProposals,researchDecisions,reviewCandidates,componentCandidates,phaseCandidates});$('#autosave-status').textContent='Autosaved '+new Date().toLocaleTimeString()}catch(e){$('#autosave-status').textContent='Autosave failed: '+e.message}}
async function restoreLocal(){try{let s=await idbGet(IDB_KEY);if(!s){const legacy=localStorage.getItem('scribe98-v05-session');if(legacy){try{s=JSON.parse(legacy);await idbSet(IDB_KEY,s)}catch{}localStorage.removeItem('scribe98-v05-session')}}if(s?.records?.length){sourceRecords=s.sourceRecords||copy(s.original);records=s.records;original=s.original;exportedCheckpoint=s.exportedCheckpoint||s.original;filename=s.filename;datasetShape=s.datasetShape;reviewStates=s.reviewStates||{};mode=s.mode||'catalogue';fixtureId=s.fixtureId||'';unescoProposals=s.unescoProposals||{};proposalDecisions=s.proposalDecisions||{};newSiteProposals=s.newSiteProposals||{};newSiteStatus=s.newSiteStatus||{};researchProposals=s.researchProposals||{};researchDecisions=s.researchDecisions||{};reviewCandidates=s.reviewCandidates||{};componentCandidates=s.componentCandidates||{};phaseCandidates=s.phaseCandidates||{};return true}}catch{}return false}
function download(name,data){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:'application/json'}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function exportCentre(){commit();const errors=records.reduce((n,r,i)=>n+validate(r,i).filter(x=>x[0]==='error').length,0),report=lossReport();$('#export-summary').textContent=`${records.length} records; ${report.summary.changed} staged; ${errors} blocking errors; ${report.summary.notices} projection notices.`;$('#export-dialog').showModal()}
function markExport(){exportedCheckpoint=copy(records);saveLocal();render()}
function changes(){return{generatedAt:new Date().toISOString(),sourceFile:filename,mode,changes:records.map((r,i)=>({r,o:original[i],i})).filter(x=>isChanged(x.i)).map(({r,o,i})=>({id:r.id,name:r.name,fields:diff(i).map(k=>({field:k,before:o[k],after:r[k]}))}))}}
// ---------------------------------------------------------------------------------------
// v0.7.0 stage-shell additions. Everything below is pure read/render or a thin wrapper that
// funnels every mutation through the exact same governed transaction helpers used everywhere
// else in this file (stageAdvancedTransaction / stageRecordReplacement) — see the module
// header comment. Nothing here invents a new mutation path.
// ---------------------------------------------------------------------------------------

// --- Home dashboard: pure counts from live state, no new state of its own. ---
function homeStats(){
  const total=records.length,changed=records.filter((_,i)=>isChanged(i)).length;
  const pendingHeritage=records.filter(r=>{const p=unescoProposals[r.id];return p&&((p.heritageProposal&&proposalStatus(r.id,'heritage')==='pending')||(p.evidenceProposal&&proposalStatus(r.id,'evidence')==='pending'))}).length;
  const pendingResearch=records.filter(r=>recordHasPendingResearch(r.id)).length;
  const pendingReview=records.filter(r=>recordHasPendingReviewCandidate(r.id)).length;
  const pendingComponent=records.filter(r=>recordHasPendingComponentCandidate(r.id)).length;
  const pendingPhase=records.filter(r=>recordHasPendingPhaseCandidate(r.id)).length;
  const newSitesPending=Object.values(newSiteStatus).filter(s=>s==='pending').length;
  const noType=records.filter(r=>!r.canonicalType).length;
  const noTags=records.filter(r=>r.tags.length===0).length;
  const noSources=records.filter(r=>r.sources.length===0).length;
  const pendingRemoval=records.filter(r=>r.workflow?.pendingRemoval).length;
  return{total,changed,pendingHeritage,pendingResearch,pendingReview,pendingComponent,pendingPhase,newSitesPending,noType,noTags,noSources,pendingRemoval};
}
function renderHome(){if(currentStage!=='home')return;const el=$('#home-summary');if(!el)return;const s=homeStats();
  el.innerHTML=`<div class="home-stats-grid">`+
    `<div class="home-stat"><b>${s.total}</b><span>Total records</span></div>`+
    `<div class="home-stat"><b>${s.changed}</b><span>Staged changes</span></div>`+
    `<div class="home-stat"><b>${s.pendingHeritage}</b><span>Pending heritage/evidence proposals</span></div>`+
    `<div class="home-stat"><b>${s.pendingResearch}</b><span>Pending research proposals</span></div>`+
    `<div class="home-stat"><b>${s.pendingReview}</b><span>Pending review candidates</span></div>`+
    `<div class="home-stat"><b>${s.pendingComponent}</b><span>Pending tag/function candidates</span></div>`+
    `<div class="home-stat"><b>${s.pendingPhase}</b><span>Pending phase candidates</span></div>`+
    `<div class="home-stat"><b>${s.newSitesPending}</b><span>New Site proposals pending</span></div>`+
    `<div class="home-stat"><b>${s.noType}</b><span>No canonical type</span></div>`+
    `<div class="home-stat"><b>${s.noTags}</b><span>No tags</span></div>`+
    `<div class="home-stat"><b>${s.noSources}</b><span>No sources</span></div>`+
    `<div class="home-stat"><b>${s.pendingRemoval}</b><span>Marked for removal</span></div>`+
    `</div><div class="home-tiles">${STAGE_META.map(t=>`<button type="button" class="home-tile" data-stage-target="${t.id}">${t.icon} ${esc(t.label)}</button>`).join('')}</div>`;
  el.querySelectorAll('[data-stage-target]').forEach(b=>b.onclick=()=>switchStage(b.dataset.stageTarget));
}

// --- Scrape overview (Scraping stage): every record with ANY pending research/review/
// component/phase candidate, reusing the existing recordHasPending*() predicates rather than
// reinventing them. No live "RUN" scraper here — DOWNLOAD SCOPE LIST is the honest equivalent:
// it exports exactly the coordinates of what's currently shown so an offline scripts/*.mjs
// adapter can be pointed at that subset by hand.
function scrapePendingList(){return records.map((r,i)=>({r,i})).filter(({r})=>recordHasPendingResearch(r.id)||recordHasPendingReviewCandidate(r.id)||recordHasPendingComponentCandidate(r.id)||recordHasPendingPhaseCandidate(r.id))}
function scrapeFiltered(){const q=($('#scrape-search')?.value||'').trim().toLowerCase(),type=$('#scrape-type-filter')?.value||'all';return scrapePendingList().filter(({r})=>{if(q){const h=[r.id,r.name,r.canonicalType].join(' ').toLowerCase();if(!h.includes(q))return false}if(type!=='all'&&r.canonicalType!==type)return false;if(scrapeChips.has('notags')&&r.tags.length!==0)return false;if(scrapeChips.has('nophases')&&(r.phases||[]).length!==0)return false;if(scrapeChips.has('nosources')&&r.sources.length!==0)return false;return true})}
function renderScrapeTypeOptions(){const sel=$('#scrape-type-filter');if(!sel)return;const cur=sel.value;sel.innerHTML='<option value="all">All types</option>'+vocab('type').map(t=>`<option value="${esc(t)}">${esc(t)}</option>`).join('');if([...sel.options].some(o=>o.value===cur))sel.value=cur}
function renderScrapeOverview(){if(currentStage!=='scraping')return;const list=$('#scrape-list');if(!list)return;renderScrapeTypeOptions();const rows=scrapeFiltered();$('#scrape-match-count').textContent=`${rows.length} record(s) match`;
  list.innerHTML=rows.map(({r,i})=>{const flags=[recordHasPendingResearch(r.id)&&'🔎',recordHasPendingReviewCandidate(r.id)&&'🧭',recordHasPendingComponentCandidate(r.id)&&'🏗',recordHasPendingPhaseCandidate(r.id)&&'📅'].filter(Boolean).join(' ');return`<div class="scrape-row" data-index="${i}"><span class="scrape-name">${esc(r.name)}</span><span class="scrape-meta">${esc(r.id)} · ${esc(r.canonicalType||'Unresolved')} · ${flags}</span><button type="button" class="win-button compact" data-scrape-review="${i}">REVIEW →</button></div>`}).join('')||'<div class="empty-phases">No records currently have a pending signal matching this filter.</div>';
  list.querySelectorAll('.scrape-row').forEach(row=>{row.onclick=e=>{if(e.target.closest('button'))return;const i=+row.dataset.index;select(i);focusOn(+records[i].latitude,+records[i].longitude,records[i].name)}});
  list.querySelectorAll('[data-scrape-review]').forEach(b=>b.onclick=e=>{e.stopPropagation();select(+b.dataset.scrapeReview);switchStage('enrichment')});
}
function downloadScrapeScope(){const rows=scrapeFiltered().map(({r})=>({id:r.id,name:r.name,latitude:r.latitude,longitude:r.longitude}));download('scribe-scrape-scope.json',JSON.stringify(rows,null,2));toast(`Downloaded scope list: ${rows.length} record(s)`)}

// --- Curator: matches every PENDING New Site proposal to its nearest EXISTING catalogue
// record within CURATOR_RADIUS_KM. Deciding never touches the pending proposal itself (New
// Sites keeps the single governed Accept/Reject path) — it only records a note on the
// EXISTING record's workflow, via the exact same stageAdvancedTransaction('workflow', …) +
// history.push pattern applyHeritageProposal() already uses above.
// v0.7.0 perf fix: this is a brute-force O(pending-proposals × records) haversine scan — with
// the real data (5,192 loaded proposals × 2,103 records) that's ~10M+ distance calculations, and
// render() calls this twice per pass (renderRecommend + renderCurator). Uncached, that made every
// stage switch/select/apply take multiple seconds — the exact "tab switching takes a few seconds"
// lag reported in real testing. Memoized here: recomputed only the first time it's asked for after
// something that could actually change the match set (curatorDirty, set by markCuratorDirty() —
// called from saveLocal(), which already fires after every real mutation in this app).
let curatorDirty=true,curatorCache=[];
function markCuratorDirty(){curatorDirty=true}
function curatorMatches(){if(!curatorDirty)return curatorCache;const pending=Object.values(newSiteProposals).filter(p=>newSiteStatus[p.proposalId]==='pending');const out=[];for(const p of pending){const lat=+p.candidate.latitude,lon=+p.candidate.longitude;if(!Number.isFinite(lat)||!Number.isFinite(lon))continue;let best=null;records.forEach((r,i)=>{const rl=+r.latitude,rn=+r.longitude;if(!Number.isFinite(rl)||!Number.isFinite(rn))return;const d=haversineKm(lat,lon,rl,rn);if(d<=CURATOR_RADIUS_KM&&(!best||d<best.distanceKm))best={distanceKm:d,record:r,index:i}});if(best)out.push({proposal:p,...best})}out.sort((a,b)=>a.distanceKm-b.distanceKm);curatorCache=out;curatorDirty=false;return out}
function curatorDecisionFor(proposalId){return records.find(r=>r.workflow?.curatorReview?.proposalId===proposalId)}
function applyCuratorDecision(match,decision){const r=match.record,idx=records.indexOf(r);const merged={...(r.workflow||{}),curatorReview:{decision,proposalId:match.proposal.proposalId,unescoId:match.proposal.unescoId,distanceKm:match.distanceKm,decidedAt:new Date().toISOString()}};try{const transaction=stageAdvancedTransaction(r,'workflow',JSON.stringify(merged),{registries:registry});records[idx]=transaction.after;history.push({index:idx,before:transaction.before,after:copy(transaction.after)});future=[];saveLocal();render();toast(`Curator decision "${decision}" recorded on ${r.name}`)}catch(e){toast('Could not record decision: '+e.message)}}
function legacyCleanupCandidates(){return records.map((r,i)=>({r,i})).filter(({r})=>r.coordinatePrecision&&r.coordinatePrecision!=='exact'&&(!r.heritage||!Object.keys(r.heritage).length)&&!r.workflow?.curatorReview)}
function curatorCaseHTML(m){const{proposal:p,record:r,distanceKm}=m,decision=curatorDecisionFor(p.proposalId);
  const decisionNote=decision?`<p class="proposal-status">Decision: ${esc(decision.workflow.curatorReview.decision)} (recorded ${esc(decision.workflow.curatorReview.decidedAt)})</p>`:`<div class="curator-decisions"><div class="curator-decision-btn"><button type="button" class="win-button compact primary" data-curator-decide="${esc(p.proposalId)}|Direct identity">SAME PLACE</button><small>The existing marker already IS this — just under a rougher record.</small></div><div class="curator-decision-btn"><button type="button" class="win-button compact" data-curator-decide="${esc(p.proposalId)}|Parent association">BELONGS TO IT</button><small>The existing marker is part of the wider property this candidate describes.</small></div><div class="curator-decision-btn"><button type="button" class="win-button compact" data-curator-decide="${esc(p.proposalId)}|Serial component">ONE PIECE OF IT</button><small>The existing marker is one physical component of this multi-part property.</small></div><div class="curator-decision-btn"><button type="button" class="win-button compact" data-curator-decide="${esc(p.proposalId)}|Supersede — existing marker is a rough placeholder for this">REPLACE OLD MARKER</button><small>The existing marker is a rough placeholder this candidate should eventually replace.</small></div></div>`;
  // v0.7.1: click-to-map + COMPARE (feature 2). The outer .curator-case keeps its original
  // candidate-coordinate data-lat/lon/label (whole-card click still focuses the single
  // minimap on the candidate, exactly as before); each .curator-col now carries its OWN
  // data-lat/lon/label — the existing record's real r.latitude/r.longitude/r.name on the
  // left, the same candidate coordinates on the right — so renderCurator() can wire each
  // column to jump the map to its own place independently. COMPARE opens the split-pane.
  return`<div class="curator-case" data-lat="${p.candidate.latitude}" data-lon="${p.candidate.longitude}" data-label="${esc(p.candidate.name)}"><div class="curator-case-header"><b>${esc(p.candidate.name)}</b><span>${distanceKm.toFixed(2)}km from “${esc(r.name)}”</span><button type="button" class="win-button compact" data-curator-compare="${esc(p.proposalId)}">⇄ COMPARE</button></div><div class="curator-compare"><div class="curator-col" data-lat="${r.latitude}" data-lon="${r.longitude}" data-label="${esc(r.name)}" title="Click to focus the map on the existing record"><b>Existing: ${esc(r.name)}</b><div class="audit-row"><b>Type</b><span>${esc(r.canonicalType||'—')}</span></div><div class="audit-row"><b>Coordinates</b><span>${(+r.latitude).toFixed(5)}, ${(+r.longitude).toFixed(5)}</span></div><div class="audit-row"><b>Precision</b><span>${esc(r.coordinatePrecision||'—')}</span></div><div class="audit-row"><b>Sources</b><span>${r.sources.length}</span></div></div><div class="curator-col" data-lat="${p.candidate.latitude}" data-lon="${p.candidate.longitude}" data-label="${esc(p.candidate.name)}" title="Click to focus the map on the candidate"><b>Candidate: ${esc(p.candidate.name)}</b><div class="audit-row"><b>Category</b><span>${esc(p.category||'—')}</span></div><div class="audit-row"><b>Description</b><span>${esc((p.candidate.description||'').slice(0,180))}</span></div>${p.candidate.heritage?.unesco?.dateInscribed?`<div class="audit-row"><b>Inscribed</b><span>${esc(p.candidate.heritage.unesco.dateInscribed)}</span></div>`:''}${p.areaHectares?`<div class="audit-row"><b>Area (ha)</b><span>${esc(p.areaHectares)}</span></div>`:''}</div></div>${decisionNote}</div>`;
}
// v0.7.0 perf fix: real testing surfaced 908 real proximity matches (the shipped UNESCO new-site
// proposals file is large — 5,192 candidates against the real catalogue). Even with curatorMatches()
// cached, building full compare-card HTML for hundreds of cases on every render was itself the
// remaining multi-second cost. Capped to the closest CURATOR_RENDER_CAP — already the most useful
// ones, since the list is distance-sorted and Recommended Next already surfaces the same order —
// with an explicit "N more not shown" note rather than a silent cutoff.
const CURATOR_RENDER_CAP=60;
function renderCurator(){if(currentStage!=='curator')return;const summary=$('#curator-summary');if(!summary)return;const matches=curatorMatches(),pending=matches.filter(m=>!curatorDecisionFor(m.proposal.proposalId)),resolved=matches.filter(m=>curatorDecisionFor(m.proposal.proposalId));
  summary.textContent=`${pending.length} pending proximity match(es), ${resolved.length} resolved, threshold ${CURATOR_RADIUS_KM}km.`;
  $$('[data-curator-tab]').forEach(b=>b.classList.toggle('active',b.dataset.curatorTab===curatorTab));
  const full=curatorTab==='pending'?pending:resolved,list=full.slice(0,CURATOR_RENDER_CAP);
  const cases=$('#curator-cases');cases.innerHTML=(list.length?list.map(curatorCaseHTML).join(''):`<div class="empty-phases">No ${esc(curatorTab)} cases.</div>`)+(full.length>CURATOR_RENDER_CAP?`<p class="proposal-status">Showing the closest ${CURATOR_RENDER_CAP} of ${full.length} — resolve these to see the next batch.</p>`:'');
  cases.querySelectorAll('[data-curator-decide]').forEach(b=>b.onclick=()=>{const idx=b.dataset.curatorDecide.indexOf('|'),proposalId=b.dataset.curatorDecide.slice(0,idx),decision=b.dataset.curatorDecide.slice(idx+1);const m=curatorMatches().find(x=>x.proposal.proposalId===proposalId);if(m)applyCuratorDecision(m,decision)});
  cases.querySelectorAll('.curator-case').forEach(card=>card.addEventListener('click',e=>{if(e.target.closest('button'))return;focusOn(+card.dataset.lat,+card.dataset.lon,card.dataset.label)}));
  // v0.7.1: each .curator-col jumps the map to its OWN coordinates (existing record on the
  // left, candidate on the right) — stopPropagation so this doesn't also re-trigger the
  // .curator-case card-level handler above with the candidate's coordinates. COMPARE opens
  // the split-pane inside the same Coordinate Inspector window (feature 2).
  cases.querySelectorAll('.curator-col').forEach(col=>col.addEventListener('click',e=>{if(e.target.closest('button'))return;e.stopPropagation();focusOn(+col.dataset.lat,+col.dataset.lon,col.dataset.label)}));
  cases.querySelectorAll('[data-curator-compare]').forEach(b=>b.onclick=e=>{e.stopPropagation();const m=curatorMatches().find(x=>x.proposal.proposalId===b.dataset.curatorCompare);if(m)enterCompareMode({lat:+m.record.latitude,lon:+m.record.longitude,label:m.record.name},{lat:+m.proposal.candidate.latitude,lon:+m.proposal.candidate.longitude,label:m.proposal.candidate.name})});
  // v0.7.1: 2-second hover tooltip on the 4 decision buttons (feature 4) — reuses the exact
  // explainer text already sitting in each button's sibling <small>, no duplicated copy.
  cases.querySelectorAll('.curator-decision-btn').forEach(wrap=>{const btn=wrap.querySelector('button'),small=wrap.querySelector('small');if(btn&&small)attachHoverTooltip(btn,small.textContent)});
  const legacy=legacyCleanupCandidates(),legacyEl=$('#curator-legacy');
  legacyEl.innerHTML=legacy.length?`<p class="proposal-status">${legacy.length} record(s) look like historical rough placeholders (imprecise coordinates, no heritage designation, no curator review).</p>`+legacy.slice(0,25).map(({r,i})=>`<div class="audit-row"><b>${esc(r.name)}</b><span>${esc(r.id)} · ${esc(r.coordinatePrecision)} <button type="button" class="win-button compact" data-legacy-edit="${i}">OPEN IN EDITOR</button></span></div>`).join(''):`<p class="proposal-status">No legacy rough-placeholder records detected.</p>`;
  legacyEl.querySelectorAll('[data-legacy-edit]').forEach(b=>b.onclick=()=>{select(+b.dataset.legacyEdit);switchStage('editor')});
}

// --- Recommended Next: rule-based, re-rendered on every render()/stage-switch, content
// differs by currentStage. Every reason cited is computed live from real state (pending
// counts, real haversine distances) — nothing here decides anything on its own.
function recommendNewSites(){const pendingList=Object.values(newSiteProposals).filter(p=>newSiteStatus[p.proposalId]==='pending');const bySibling={};pendingList.forEach(p=>{(bySibling[p.unescoId]=bySibling[p.unescoId]||[]).push(p)});const matches=curatorMatches(),matchByProposal=new Map(matches.map(m=>[m.proposal.proposalId,m]));const independent=[],duplicates=[];for(const p of pendingList){const m=matchByProposal.get(p.proposalId);if(m){duplicates.push(m);continue}if(bySibling[p.unescoId].length===1)independent.push(p)}return{independent,duplicates:duplicates.sort((a,b)=>a.distanceKm-b.distanceKm)}}
function renderRecommend(){const el=$('#recommend-body');if(!el)return;if(!['enrichment','newsites','curator'].includes(currentStage))return;let html='';
  if(currentStage==='enrichment'){
    const scored=records.map((r,i)=>{const reasons=[];const up=unescoProposals[r.id];if(up&&((up.heritageProposal&&proposalStatus(r.id,'heritage')==='pending')||(up.evidenceProposal&&proposalStatus(r.id,'evidence')==='pending')))reasons.push('pending heritage/evidence proposal');if(recordHasPendingResearch(r.id))reasons.push('pending research proposal');if(recordHasPendingReviewCandidate(r.id))reasons.push('pending review candidate');if(recordHasPendingComponentCandidate(r.id))reasons.push('pending tag/function candidate');if(recordHasPendingPhaseCandidate(r.id))reasons.push('pending phase candidate');if(!r.canonicalType)reasons.push('missing canonical type');return{r,i,reasons}}).filter(x=>x.reasons.length>=2).sort((a,b)=>b.reasons.length-a.reasons.length).slice(0,8);
    html=scored.length?`<ul class="recommend-list">${scored.map(x=>`<li><b>${esc(x.r.name)}</b> has ${x.reasons.length} pending signals stacked (${x.reasons.join(', ')}) — resolving all at once is efficient. <button type="button" class="win-button compact" data-recommend-select="${x.i}">OPEN</button></li>`).join('')}</ul>`:`<p class="proposal-status">No record currently has more than one pending signal stacked.</p>`;
  } else if(currentStage==='newsites'){
    const{independent,duplicates}=recommendNewSites();let parts=[];
    if(independent.length)parts.push(`<li class="recommend-group-label">No ambiguity — fastest safe accepts:</li>`+independent.slice(0,6).map(p=>`<li><b>${esc(p.candidate.name)}</b> — single, non-grouped pending candidate.</li>`).join(''));
    if(duplicates.length)parts.push(`<li class="recommend-group-label">Possible duplicates — resolve in Curator first:</li>`+duplicates.slice(0,6).map(m=>`<li><b>${esc(m.proposal.candidate.name)}</b> is ${m.distanceKm.toFixed(2)}km from existing record <b>${esc(m.record.name)}</b>. <button type="button" class="win-button compact" data-recommend-curator>RESOLVE IN CURATOR</button></li>`).join(''));
    html=parts.length?`<ul class="recommend-list">${parts.join('')}</ul>`:`<p class="proposal-status">No pending New Site proposals loaded.</p>`;
  } else if(currentStage==='curator'){
    const matches=curatorMatches().filter(m=>!curatorDecisionFor(m.proposal.proposalId));
    html=matches.length?`<ul class="recommend-list">${matches.slice(0,10).map(m=>`<li><b>${esc(m.proposal.candidate.name)}</b> is ${m.distanceKm.toFixed(2)}km from existing record <b>${esc(m.record.name)}</b> — closest pending match.</li>`).join('')}</ul>`:`<p class="proposal-status">No pending proximity matches.</p>`;
  }
  html+=`<p class="recommend-footer">Reasons shown are simple, visible rules — not a hidden score. Recommended, never decided.</p>`;
  el.innerHTML=html;
  el.querySelectorAll('[data-recommend-select]').forEach(b=>b.onclick=()=>select(+b.dataset.recommendSelect));
  el.querySelectorAll('[data-recommend-curator]').forEach(b=>b.onclick=()=>switchStage('curator'));
}

function render(){renderChronoNav();renderList();fill();renderCoordEdit();renderNewSites();renderHome();renderScrapeOverview();renderRecommend();renderCurator();const changed=records.filter((_,i)=>isChanged(i)).length;$('#dataset-name').textContent=filename;$('#top-status').textContent=`${records.length} records · ${changed} staged${hasUnexported()?' · UNEXPORTED':''}`;$('.status-card').classList.toggle('unexported',hasUnexported());$('#undo').disabled=!history.length;$('#redo').disabled=!future.length}
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));function toast(m){const e=$('#toast');e.textContent=m;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2400)}
// v0.7.1: reusable 2-second hover tooltip (feature 4) — a genuine delayed custom tooltip, not
// a native `title` (no reliable 2s delay, inconsistent styling). Only wired onto the 4
// Curator decision buttons today (see renderCurator()), but takes any element + text so it
// can be reused elsewhere later without new plumbing.
function attachHoverTooltip(el,text){let timer=null,tipEl=null;const clear=()=>{if(timer){clearTimeout(timer);timer=null}if(tipEl){tipEl.remove();tipEl=null}};el.addEventListener('mouseenter',()=>{clear();timer=setTimeout(()=>{const r=el.getBoundingClientRect();tipEl=document.createElement('div');tipEl.className='tooltip';tipEl.textContent=text;document.body.appendChild(tipEl);tipEl.style.left=Math.round(Math.min(r.left,innerWidth-tipEl.offsetWidth-8))+'px';tipEl.style.top=Math.round(r.bottom+6)+'px'},2000)});el.addEventListener('mouseleave',clear);el.addEventListener('click',clear)}
$('#add-component').onclick=()=>{$('#components-editor .empty-phases')?.remove();$('#components-editor').insertAdjacentHTML('beforeend',componentHTML());bindRemovers('#components-editor')};
$('#advanced-dimension').innerHTML=ADVANCED_DIMENSIONS.map(v=>`<option value="${v}">${v}</option>`).join('');
$('#advanced-dimension').onchange=e=>{advancedDimension=e.target.value;renderAdvanced()};
$('#format-advanced').onclick=formatAdvanced;
$('#apply-advanced').onclick=applyAdvanced;

function bind(){ $('#file-input').onchange=e=>e.target.files[0]&&importFile(e.target.files[0]);$('#proposals-input').onchange=e=>{e.target.files[0]&&loadProposals(e.target.files[0]);e.target.value=''};$('#newsites-input').onchange=e=>{e.target.files[0]&&loadNewSiteProposals(e.target.files[0]);e.target.value=''};$('#research-input').onchange=e=>{e.target.files[0]&&loadResearchProposals(e.target.files[0]);e.target.value=''};$('#pleiades-input').onchange=e=>{e.target.files[0]&&loadPleiadesProposals(e.target.files[0]);e.target.value=''};$('#review-input').onchange=e=>{e.target.files[0]&&loadReviewCandidates(e.target.files[0]);e.target.value=''};$('#component-input').onchange=e=>{e.target.files[0]&&loadComponentCandidates(e.target.files[0]);e.target.value=''};$('#phase-input').onchange=e=>{e.target.files[0]&&loadPhaseCandidates(e.target.files[0]);e.target.value=''};$('#newsite-search').oninput=renderNewSites;$('#newsite-category-filter').onchange=renderNewSites;$('#accept-all-filtered').onclick=acceptAllFiltered;$('#reject-all-filtered').onclick=rejectAllFiltered;$('#toggle-accepted').onclick=()=>$('#newsite-accepted-list').classList.toggle('hidden');$('#fixture-mode').onclick=()=>fixture(fixtureId||undefined);$('#fixture-picker').onchange=e=>fixture(e.target.value);$('#reset-fixture').onclick=()=>fixture(fixtureId);$('#record-form').onsubmit=e=>{e.preventDefault();commit();toast('Changes staged')};$('#search').oninput=renderList;$('#issue-filter').onchange=renderList;$('#clear-search').onclick=()=>{$('#search').value='';renderList()};$('#undo').onclick=undo;$('#redo').onclick=redo;$('#revert-record').onclick=revert;$('#toggle-removal').onclick=toggleRemoval;$('#bulk-mark-removal').onclick=markSelectedForRemoval;$('#previous-record').onclick=()=>select(selected-1);$('#next-record').onclick=()=>select(selected+1);$('#save-session').onclick=()=>{commit();saveLocal();toast('Session saved')};$('#export-json').onclick=exportCentre;$('#close-export').onclick=()=>$('#export-dialog').close();$('#download-canonical').onclick=()=>{download(filename.replace(/\.json$/i,'')+'_canonical.json',JSON.stringify(records.map((r,i)=>({r,i})).filter(x=>!x.r.workflow?.pendingRemoval).map(x=>canonical(x.r)),null,2));markExport()};$('#download-dataset').onclick=()=>{download(filename.replace(/\.json$/i,'')+'_public-legacy.json',JSON.stringify(records.map((r,i)=>({r,i})).filter(x=>!x.r.workflow?.pendingRemoval).map(x=>projection(x.r,x.i)),null,2));markExport()};$('#download-loss-report').onclick=()=>download('scribe-projection-loss-report.json',JSON.stringify(lossReport(),null,2));$('#download-changes').onclick=()=>download('scribe-changeset.json',JSON.stringify(changes(),null,2));
 $('#add-phase').onclick=()=>{$('#phases-editor .empty-phases')?.remove();$('#phases-editor').insertAdjacentHTML('beforeend',phaseHTML());bindRemovers('#phases-editor')};$('#add-chronology').onclick=()=>{$('#chronology-editor .empty-phases')?.remove();$('#chronology-editor').insertAdjacentHTML('beforeend',chronologyHTML());bindRemovers('#chronology-editor')};$('#add-relationship').onclick=()=>{$('#relationships-editor .empty-phases')?.remove();$('#relationships-editor').insertAdjacentHTML('beforeend',relationshipHTML());bindRemovers('#relationships-editor')};$('#add-evidence').onclick=()=>{$('#evidence-editor .empty-phases')?.remove();$('#evidence-editor').insertAdjacentHTML('beforeend',evidenceHTML());bindRemovers('#evidence-editor')};$('#add-condition').onclick=()=>{$('#condition-editor .empty-phases')?.remove();$('#condition-editor').insertAdjacentHTML('beforeend',conditionHTML());bindRemovers('#condition-editor')};$('#add-investigation').onclick=()=>{$('#investigation-editor .empty-phases')?.remove();$('#investigation-editor').insertAdjacentHTML('beforeend',investigationHTML());bindRemovers('#investigation-editor')};$('#satellite-map').onclick=moveCoordinates;$('#zoom-in').onclick=()=>{mapZoom=Math.min(19,mapZoom+1);renderMap()};$('#zoom-out').onclick=()=>{mapZoom=Math.max(2,mapZoom-1);renderMap()};$('#goto-coordinates').onclick=()=>{commit();renderMap()};$('#copy-coordinates').onclick=()=>navigator.clipboard.writeText(`${$('[name=latitude]').value}, ${$('[name=longitude]').value}`).then(()=>toast('Coordinates copied'));$('#restore-coordinates').onclick=()=>{$('[name=latitude]').value=original[selected].latitude;$('[name=longitude]').value=original[selected].longitude;commit()};$$('[data-review]').forEach(b=>b.onclick=()=>setReview(b.dataset.review));$$('[data-preview]').forEach(b=>b.onclick=()=>{previewMode=b.dataset.preview;renderPreview()});
 $$('.taxonomy-toggle').forEach(b=>b.onclick=()=>{const f=b.closest('.taxonomy-field');$$('.taxonomy-field').forEach(x=>x!==f&&x.classList.remove('open'));f.classList.toggle('open')});$$('.taxonomy-search').forEach(i=>i.oninput=()=>renderTaxonomy(i.closest('.taxonomy-field')));$$('.clear-taxonomy').forEach(b=>b.onclick=()=>{const f=b.closest('.taxonomy-field');taxSelections[f.dataset.taxonomy]=[];renderTaxonomy(f)});addEventListener('click',e=>{if(!e.target.closest('.taxonomy-field'))$$('.taxonomy-field').forEach(x=>x.classList.remove('open'))});addEventListener('keydown',e=>{if(e.ctrlKey&&e.key.toLowerCase()==='s'){e.preventDefault();commit();saveLocal()}if(e.ctrlKey&&e.key.toLowerCase()==='z'){e.preventDefault();undo()}if(e.ctrlKey&&e.key.toLowerCase()==='y'){e.preventDefault();redo()}if(e.altKey&&e.key==='ArrowLeft'){e.preventDefault();select(selected-1)}if(e.altKey&&e.key==='ArrowRight'){e.preventDefault();select(selected+1)}});addEventListener('beforeunload',e=>{if(hasUnexported()){e.preventDefault();e.returnValue=''}});
 // v0.7.0 stage-shell bindings: stage tabs, Scraping stage's search/type/chip filters and
 // scope-list download, Curator's pending/resolved tabs.
 $$('.stage-tab').forEach(b=>b.onclick=()=>switchStage(b.dataset.stageTarget));
 $('#scrape-search').oninput=renderScrapeOverview;$('#scrape-type-filter').onchange=renderScrapeOverview;$('#scrape-download-scope').onclick=downloadScrapeScope;
 $$('.scrape-chip').forEach(b=>b.onclick=()=>{const k=b.dataset.chip;if(scrapeChips.has(k))scrapeChips.delete(k);else scrapeChips.add(k);b.classList.toggle('active',scrapeChips.has(k));renderScrapeOverview()});
 $$('[data-curator-tab]').forEach(b=>b.onclick=()=>{curatorTab=b.dataset.curatorTab;renderCurator()});
 // v0.7.1: mousewheel zoom (feature 3) on the single map and both compare panes — see
 // onMapWheel()/tileLayerHTML() above. {passive:false} so preventDefault() actually stops the
 // page itself from scrolling.
 $('#satellite-map').addEventListener('wheel',onMapWheel,{passive:false});
 $$('.map-compare-canvas').forEach(el=>el.addEventListener('wheel',onMapWheel,{passive:false}));
 $('#map-compare-exit').onclick=exitCompareMode;
 // v0.7.2: chronological navigator + sort (feature 1). Two thumbs over one track, the two number
 // fields, the two outlier toggles, CLEAR DATES and the sort select all write the same handful of
 // module-level values above and then re-render the list — there is no second filtering path.
 ['min','max'].forEach(which=>{const el=$('#chrono-thumb-'+which);if(!el)return;
   el.addEventListener('pointerdown',e=>{e.preventDefault();chronoDragWhich=which;el.focus();try{el.setPointerCapture(e.pointerId)}catch{}setChrono(which,chronoValueFromX(e.clientX))});
   el.addEventListener('pointermove',e=>{if(chronoDragWhich===which)setChrono(which,chronoValueFromX(e.clientX))});
   el.addEventListener('pointerup',e=>{if(chronoDragWhich!==which)return;chronoDragWhich=null;try{el.releasePointerCapture(e.pointerId)}catch{}});
   // Keyboard equivalent of the drag, so the slider is not a mouse-only control.
   el.addEventListener('keydown',e=>{const step=e.shiftKey?1000:100;let d=0;if(e.key==='ArrowLeft'||e.key==='ArrowDown')d=-step;else if(e.key==='ArrowRight'||e.key==='ArrowUp')d=step;else if(e.key==='Home')d=-1e9;else if(e.key==='End')d=1e9;else return;e.preventDefault();setChrono(which,(which==='min'?chronoMin:chronoMax)+d)})});
 $('#chrono-track')?.addEventListener('pointerdown',e=>{if(e.target.classList.contains('chrono-thumb'))return;const v=chronoValueFromX(e.clientX);setChrono(Math.abs(v-chronoMin)<=Math.abs(v-chronoMax)?'min':'max',v)});
 $('#chrono-min').oninput=e=>{const v=Number(e.target.value);if(e.target.value===''||!Number.isFinite(v))return;setChrono('min',v)};
 $('#chrono-max').oninput=e=>{const v=Number(e.target.value);if(e.target.value===''||!Number.isFinite(v))return;setChrono('max',v)};
 // The two outlier catches. These ADD records back in — a record dated outside the working range
 // shows whenever its side is toggled on, no matter how narrow the range is — they never narrow.
 $('#chrono-before').onclick=()=>{chronoBefore=!chronoBefore;renderChronoNav();renderList()};
 $('#chrono-after').onclick=()=>{chronoAfter=!chronoAfter;renderChronoNav();renderList()};
 $('#chrono-clear').onclick=clearChrono;
 $('#record-sort').onchange=e=>{recordSort=e.target.value;renderList()};
 // v0.7.2: EDIT COORDINATES (feature 2). A real grab-and-drag marker: pointerdown on the visible
 // marker captures the pointer, pointermove repositions it live (marker only — no tile re-render
 // per mousemove), pointerup drops it. Clicking elsewhere on the imagery while in edit mode moves
 // it there too (see moveCoordinates()); both only ever set the PENDING position.
 $('#edit-coordinates').onclick=()=>coordEdit?cancelCoordEdit():enterCoordEdit();
 $('#save-coordinates').onclick=saveCoordEdit;
 $('#cancel-coordinates').onclick=()=>cancelCoordEdit();
 const coordMarker=$('#coord-edit-marker');
 if(coordMarker){
   coordMarker.addEventListener('pointerdown',e=>{if(!coordEdit)return;e.preventDefault();e.stopPropagation();coordDragging=true;coordMarker.classList.add('dragging');try{coordMarker.setPointerCapture(e.pointerId)}catch{}});
   coordMarker.addEventListener('pointermove',e=>{if(!coordDragging)return;const p=coordFromPointer(e.clientX,e.clientY);if(p){coordPending=p;renderCoordEdit()}});
   coordMarker.addEventListener('pointerup',e=>{if(!coordDragging)return;coordDragging=false;coordMarker.classList.remove('dragging');try{coordMarker.releasePointerCapture(e.pointerId)}catch{}const p=coordFromPointer(e.clientX,e.clientY);if(p){coordPending=p;renderCoordEdit()}});
   coordMarker.addEventListener('click',e=>e.stopPropagation());
 }
 initMenuBar();
}

// v0.7.1: Win98 dropdown menu bar (feature 5) — replaces the old flat .toolbar row. Every
// element that already had an id/onclick (file-input, fixture-mode, save-session, undo,
// redo, reset-layout, lock-windows, fullscreen, export-json) kept it and is bound exactly
// where it always was, above — this only wires the NEW menu chrome (open/close/hover-switch)
// and the additive mirror items (Open New Site Proposals, Import submenu, Go to Stage
// submenu, Mark for Removal/Restore, Jump to Selected Record, Download Scope List, Exit),
// each of which calls the exact same existing hidden input or function its stage-window
// original already uses — no new governed-write logic anywhere in this function.
// v0.7.2 (bug 4): the submenu open-state class moved from the trigger itself to its
// .menu-submenu-wrap, because the trigger is a real <button> now and can no longer contain the
// submenu it opens. .menu-submenu-parent.open is still cleared too, so nothing is left behind.
function closeMenus(){$$('.menu.open').forEach(m=>m.classList.remove('open'));$$('.menu-submenu-wrap.open,.menu-submenu-parent.open').forEach(m=>m.classList.remove('open'))}
function initMenuBar(){
  $$('.menu').forEach(menu=>{
    const label=menu.querySelector('.menu-label');
    label.onclick=e=>{e.stopPropagation();const open=menu.classList.contains('open');closeMenus();if(!open)menu.classList.add('open')};
    label.addEventListener('mouseenter',()=>{if($('.menu.open')&&!menu.classList.contains('open')){closeMenus();menu.classList.add('open')}});
  });
  // v0.7.2 (bug 4): File ▸ Import and View ▸ Go to Stage were unreachable by keyboard — their
  // trigger was a plain <div> (not a tab stop) and their children were display:none (never tab
  // stops in any browser), so Tab skipped the trigger AND all 11 items behind the two of them. The
  // trigger is a real <button> now, so Tab reaches it and Enter/Space activates it; the CSS
  // :focus-within rule added alongside the existing :hover/.open selector is what lets Tab carry
  // straight on into the now-visible children. ArrowRight is the conventional extra way in.
  $$('.menu-submenu-parent').forEach(p=>{const wrap=p.closest('.menu-submenu-wrap')||p;
    p.addEventListener('click',e=>{e.stopPropagation();wrap.classList.toggle('open')});
    p.addEventListener('keydown',e=>{if(e.key!=='ArrowRight')return;e.preventDefault();wrap.classList.add('open');wrap.querySelector('.menu-submenu .menu-item')?.focus()})});
  $$('.menu-item:not(.menu-submenu-parent)').forEach(it=>it.addEventListener('click',()=>closeMenus()));
  addEventListener('click',e=>{if(!e.target.closest('.menu'))closeMenus()});
  addEventListener('keydown',e=>{if(e.key==='Escape')closeMenus()});
  // v0.7.2 (bug 3): an open dropdown used to close only on an outside mouse click or Escape, so
  // opening a menu with the keyboard and then tabbing past its last item left it hanging open over
  // the page while focus had already moved on. Close whenever focus lands anywhere outside the menu
  // bar — relatedTarget covers the normal case, and the deferred activeElement re-check covers the
  // browsers/paths where relatedTarget is null but focus did stay inside.
  const menubar=$('.menubar');
  if(menubar)menubar.addEventListener('focusout',e=>{if(e.relatedTarget&&menubar.contains(e.relatedTarget))return;setTimeout(()=>{if(!menubar.contains(document.activeElement))closeMenus()},0)});
  // File: mirrors of the New Site / Import loaders that live in their own stage windows —
  // trigger the exact same hidden inputs already bound onchange in bind() above.
  $$('[data-menu-trigger]').forEach(b=>b.onclick=()=>$('#'+b.dataset.menuTrigger)?.click());
  $$('[data-menu-action="exit"]').forEach(b=>b.onclick=()=>toast('Nothing to exit to — just close the tab'));
  // View > Go to Stage: mirrors the .stage-tab buttons via the same switchStage() function.
  $$('[data-menu-stage]').forEach(b=>b.onclick=()=>switchStage(b.dataset.menuStage));
  // Edit > Mark for Removal/Restore: mirrors #toggle-removal, same toggleRemoval() call.
  $('#menu-mark-removal').onclick=()=>{if(records[selected])toggleRemoval()};
  // Edit > Jump to Selected Record: small convenience — make sure the selected record's
  // stage is showing and its row is scrolled into view in the catalogue list.
  $('#menu-jump-selected').onclick=()=>{if(!records[selected])return;if(currentStage!=='enrichment'&&currentStage!=='editor')switchStage('enrichment');select(selected);$('.record-item.selected')?.scrollIntoView({block:'center'})};
  // Tools > Download Scope List: mirrors #scrape-download-scope, same downloadScrapeScope().
  $('#menu-download-scope').onclick=downloadScrapeScope;
}

const desktop=$('.desktop'),wins=[...desktop.querySelectorAll(':scope > .window')];let topZ=20,drag=null;desktop.classList.add('window-desktop');
function setupWindows(){wins.forEach(w=>{const bar=w.querySelector('.titlebar');bar.querySelector('.controls')?.remove();const c=document.createElement('span');c.className='window-control-group';c.innerHTML='<button class="window-control" type="button">_</button><button class="window-control" type="button">□</button>';bar.appendChild(c);w.appendChild(Object.assign(document.createElement('span'),{className:'resize-grip'}));bar.onpointerdown=startDrag;bar.ondblclick=()=>maximize(w);w.onpointerdown=()=>focus(w);c.onpointerdown=e=>e.stopPropagation();c.children[0].onclick=()=>minimize(w);c.children[1].onclick=()=>maximize(w);new ResizeObserver(()=>{if(w.classList.contains('map-window'))renderMap();if(!w.classList.contains('layout-applying')&&!w.classList.contains('stage-hidden'))saveLayout()}).observe(w)})}

// v0.7.0: the windowing engine used to hard-code exactly 7 windows in a fixed positional
// order (a literal per-index windowId array, and defaults() hand-tuned pixel math per index). Once
// windows are shown/hidden per stage and new ones exist, that breaks — reworked to read each
// window's own data-win attribute (set once in index.html, matching the window's purpose) and
// to compute layout only for the windows visible in the CURRENT stage, using a generalized
// weighted-column model: each data-win id has a {col, hf} hint below — col 0/1/2 is the
// narrow-left / wide-center / narrow-right-stacked column the old layout already used, hf is
// its height-share within whichever OTHER windows are concurrently visible in that same
// column for the current stage (irrelevant, i.e. it gets 100% of the column, when it's the
// only one visible there). A column with nothing visible in it contributes no width, so e.g.
// the Home stage's lone window gets the full desktop width.
// v0.7.1: editor gets a minW hint — see computeDefaults() below, where a center-column
// window's minW widens the center column (at the right column's expense, down to its own
// 280px floor) so the Editor's new 2-column fieldset reflow (feature 1) has real room.
const WIN_HINTS={catalogue:{col:0,hf:.62},recommend:{col:0,hf:.38},sources:{col:0,hf:1},editor:{col:1,hf:1,minW:820},newsites:{col:1,hf:1},scrapeoverview:{col:1,hf:1},curator:{col:1,hf:1},home:{col:1,hf:1,maxW:1040,maxH:420},map:{col:2,hf:.32},validation:{col:2,hf:.17},audit:{col:2,hf:.14},projection:{col:2,hf:.37}};
function stageWindows(){return wins.filter(w=>(w.dataset.stage||'').split(/\s+/).includes(currentStage))}
function applyStageVisibility(){const visible=new Set(stageWindows());wins.forEach(w=>w.classList.toggle('stage-hidden',!visible.has(w)))}
function computeDefaults(visible){const top=Math.max(78,$('.appbar').getBoundingClientRect().bottom+8),h=Math.max(360,innerHeight-top-8);
  if(innerWidth<850)return visible.map((w,i)=>({win:w.dataset.win,x:10+i*22,y:top+i*28,w:innerWidth-60,h:Math.max(320,h-i*20)}));
  // A lone window on its stage (Home today; any future single-window stage) gets a capped,
  // centered box instead of stretching edge-to-edge — a full-bleed 1920px-wide dashboard read as
  // "broken/fullscreen" in real testing rather than a normal desktop window.
  if(visible.length===1){const w0=visible[0],hint=WIN_HINTS[w0.dataset.win]||{};if(hint.maxW||hint.maxH){const capW=Math.min(innerWidth-32,hint.maxW||innerWidth-32),capH=Math.min(h,hint.maxH||h);return[{win:w0.dataset.win,x:Math.max(8,Math.round((innerWidth-capW)/2)),y:top+Math.max(0,Math.round((h-capH)/2)),w:capW,h:capH}]}}
  const byCol=[[],[],[]];visible.forEach(w=>{const hint=WIN_HINTS[w.dataset.win]||{col:1,hf:1};byCol[hint.col].push(w)});
  const hasL=byCol[0].length>0,hasR=byCol[2].length>0;
  const lw=hasL?Math.min(290,Math.max(230,innerWidth*.22)):0;
  let rw=hasR?Math.min(360,Math.max(280,innerWidth*.25)):0;
  const xC=8+(hasL?lw+8:0);
  let cw=Math.max(360,innerWidth-xC-(hasR?rw+8:0)-8);
  // v0.7.1: give a center-column window's minW hint (Editor only, today) room by shrinking
  // the right column down to its own 280px floor first, instead of changing every other
  // stage's fixed left/right proportions.
  const centerMinW=Math.max(0,...byCol[1].map(w=>WIN_HINTS[w.dataset.win]?.minW||0));
  if(centerMinW>cw){const gain=Math.min(centerMinW-cw,Math.max(0,rw-280));rw-=gain;cw+=gain}
  const xR=innerWidth-rw-8;
  const out=new Map();
  function stackCol(list,x,w){const totalHf=list.reduce((n,win)=>n+(WIN_HINTS[win.dataset.win]?.hf||1),0)||1;let y=top;for(const win of list){const hf=(WIN_HINTS[win.dataset.win]?.hf||1)/totalHf,winH=Math.max(80,Math.round(h*hf));out.set(win,{x,y,w,h:winH});y+=winH+8}}
  stackCol(byCol[0],8,lw);stackCol(byCol[1],xC,cw);stackCol(byCol[2],xR,rw);
  return visible.map(w=>({win:w.dataset.win,...out.get(w)}));
}
function applyLayout(list){const visible=stageWindows(),byWin=Object.fromEntries((list||[]).map(p=>[p.win,p])),defByWin=Object.fromEntries(computeDefaults(visible).map(p=>[p.win,p]));visible.forEach(w=>{const p=byWin[w.dataset.win]||defByWin[w.dataset.win];if(!p)return;w.classList.add('layout-applying');Object.assign(w.style,{left:p.x+'px',top:p.y+'px',width:p.w+'px',height:p.h+'px',zIndex:String(++topZ)});w.classList.toggle('minimized',!!p.minimized);w.dataset.prevRect=p.prevRect?JSON.stringify(p.prevRect):'';requestAnimationFrame(()=>w.classList.remove('layout-applying'))});setTimeout(renderMap)}
function layoutKey(){return`scribe98-window-layout-v07-${currentStage}`}
function saveLayout(){const visible=stageWindows();localStorage.setItem(layoutKey(),JSON.stringify(visible.map(w=>{const r=w.getBoundingClientRect();return{win:w.dataset.win,x:Math.round(r.left),y:Math.round(r.top),w:Math.round(r.width),h:Math.round(r.height),minimized:w.classList.contains('minimized'),prevRect:w.dataset.prevRect?JSON.parse(w.dataset.prevRect):null}})))}
function loadLayout(){try{const a=JSON.parse(localStorage.getItem(layoutKey())),visible=stageWindows();if(Array.isArray(a)&&a.length===visible.length&&a.every(p=>visible.some(w=>w.dataset.win===p.win)))return applyLayout(a)}catch{}applyLayout()}
function switchStage(stage){if(!STAGES.includes(stage))return;cancelCoordEdit(true);commit();currentStage=stage;try{localStorage.setItem('scribe98-current-stage',stage)}catch{}if(stage==='enrichment'||stage==='editor')focusCoords=null;if(stage!=='curator'&&compareMode)exitCompareMode();applyStageVisibility();$$('.stage-tab').forEach(b=>b.classList.toggle('active',b.dataset.stageTarget===stage));loadLayout();render()}
function focus(w){w.style.zIndex=String(++topZ);wins.forEach(x=>x.querySelector('.titlebar').classList.toggle('active',x===w))}function startDrag(e){if(windowsLocked||e.button||e.target.closest('button'))return;const w=e.currentTarget.closest('.window'),r=w.getBoundingClientRect();drag={w,dx:e.clientX-r.left,dy:e.clientY-r.top};focus(w);w.classList.add('dragging')}function minimize(w){if(!w.classList.contains('minimized'))w.dataset.restoreHeight=w.style.height;w.classList.toggle('minimized');if(!w.classList.contains('minimized'))w.style.height=w.dataset.restoreHeight;saveLayout()}function maximize(w){if(w.dataset.prevRect){const p=JSON.parse(w.dataset.prevRect);Object.assign(w.style,{left:p.x+'px',top:p.y+'px',width:p.w+'px',height:p.h+'px'});w.dataset.prevRect=''}else{const r=w.getBoundingClientRect(),top=$('.appbar').getBoundingClientRect().bottom;w.dataset.prevRect=JSON.stringify({x:r.left,y:r.top,w:r.width,h:r.height});Object.assign(w.style,{left:'4px',top:top+'px',width:innerWidth-8+'px',height:innerHeight-top-4+'px'})}w.classList.remove('minimized');saveLayout();renderMap()}
addEventListener('pointermove',e=>{if(!drag)return;drag.w.style.left=Math.min(innerWidth-80,Math.max(0,e.clientX-drag.dx))+'px';drag.w.style.top=Math.min(innerHeight-24,Math.max($('.appbar').getBoundingClientRect().bottom,e.clientY-drag.dy))+'px'});addEventListener('pointerup',()=>{if(drag){drag.w.classList.remove('dragging');drag=null;saveLayout()}});addEventListener('resize',()=>applyLayout());
$('#reset-layout').onclick=()=>{localStorage.removeItem(layoutKey());applyLayout();toast('Desktop layout reset')};$('#lock-windows').onclick=()=>{windowsLocked=!windowsLocked;wins.forEach(w=>w.classList.toggle('locked-window',windowsLocked));$('#lock-windows').textContent=windowsLocked?'🔒 WINDOWS LOCKED':'🔓 LOCK WINDOWS';localStorage.setItem('scribe98-windows-locked',windowsLocked)};$('#fullscreen').onclick=()=>document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen();

// v0.6.0 fix (still applies, generalized to per-stage windows): setupWindows() attaches a
// ResizeObserver to every window before the `await restoreLocal()` gap below, and each
// observer fires an initial callback once the window has settled — which, per spec, happens
// on the next rendering opportunity, not synchronously. Restoring the real ~2,100-record
// catalogue from IndexedDB takes long enough that the observer's initial callback can fire
// *during* the await, while a window is still at its unpositioned default — and its callback
// calls saveLayout(), which would clobber the real saved layout with that snapshot. Fix: apply
// stage visibility and the real layout synchronously before the async gap, so whenever the
// observer's first callback does fire, it saves the *correct* already-applied rect.
async function boot(){await loadAssets();$('#fixture-picker').innerHTML=fixtureManifest.fixtures.map(f=>`<option value="${f.id}">${f.id} — ${esc(f.label)}</option>`).join('');setupWindows();bind();
  try{const saved=localStorage.getItem('scribe98-current-stage');currentStage=STAGES.includes(saved)?saved:'home'}catch{currentStage='home'}
  applyStageVisibility();$$('.stage-tab').forEach(b=>b.classList.toggle('active',b.dataset.stageTarget===currentStage));loadLayout();
  const restored=await restoreLocal();if(!restored){records=normalize(demo);original=copy(records);exportedCheckpoint=copy(records)}if(mode==='fixture'){$('#fixture-picker-wrap').classList.remove('hidden');$('#fixture-mode').innerHTML='🧪 <span class="mode-lamp">FIXTURE MODE</span>';$('#fixture-picker').value=fixtureId}windowsLocked=localStorage.getItem('scribe98-windows-locked')==='true';render();if(restored)toast('Recovered your last Scribe session')}
boot().catch(e=>{$('#top-status').textContent='Startup failed: '+e.message;console.error(e)});
