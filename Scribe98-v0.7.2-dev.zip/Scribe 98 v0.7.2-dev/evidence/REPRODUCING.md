# Reproducing the Scribe v0.6.8 evidence

Requirements: Node.js 20 or later and the frozen 2,103-record ArcheoMaps catalogue with SHA-256 `e3258b0cffb2dec1a18b224e8dd834161c9725a9b02d4c7abe99b1ec378fbdff`.

From the Scribe repository root:

```sh
npm test
```

To run the two evidence stages separately:

```sh
npm run gauntlet
npm run roundtrip -- /absolute/path/to/archeomaps_data.json
```

The fixture stage recreates this directory before writing F01–F15 evidence. The catalogue stage verifies the source count and SHA-256 before testing any record. A failed assertion or mismatch exits non-zero.

`SHA256SUMS.txt` hashes every evidence deliverable except the manifest itself. Identical inputs and source code produce identical artifacts.
