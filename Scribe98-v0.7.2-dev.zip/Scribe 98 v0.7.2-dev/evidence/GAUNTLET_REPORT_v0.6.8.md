# Scribe v0.6.8 — Evidence Gauntlet

Overall verdict: **Supported Pass**

This report summarizes executable behavioral evidence. Every fixture has a separate JSON artifact containing its exact input, operation, staged result, canonical output, legacy projection, loss report, structural diff, expected-versus-actual assertions, and undo/redo results.

| Fixture | Verdict | Assertions | Evidence artifact |
|---|---|---:|---|
| F01 — Gobekli Tepe — complex and phases | Supported Pass | 6/6 | `artifacts/v0.6.8/fixtures/F01.json` |
| F02 — Forum Romanum — multi-period place | Supported Pass | 6/6 | `artifacts/v0.6.8/fixtures/F02.json` |
| F03 — Hagia Sophia — conversion history | Supported Pass | 6/6 | `artifacts/v0.6.8/fixtures/F03.json` |
| F04 — Lascaux — cave-art adjudication | Supported Pass | 6/6 | `artifacts/v0.6.8/fixtures/F04.json` |
| F05 — Cheomseongdae — purpose-built observatory | Supported Pass | 7/7 | `artifacts/v0.6.8/fixtures/F05.json` |
| F06 — Zorats Karer — astronomical monument claim | Supported Pass | 6/6 | `artifacts/v0.6.8/fixtures/F06.json` |
| F07 — Buddhas of Bamiyan — destruction and evidence | Supported Pass | 6/6 | `artifacts/v0.6.8/fixtures/F07.json` |
| F08 — Abu Simbel — relocation and UNESCO parent | Supported Pass | 6/6 | `artifacts/v0.6.8/fixtures/F08.json` |
| F09 — Pavlopetri — submerged approximate site | Supported Pass | 6/6 | `artifacts/v0.6.8/fixtures/F09.json` |
| F10 — Via Appia — linear serial resource | Supported Pass | 6/6 | `artifacts/v0.6.8/fixtures/F10.json` |
| F11 — Khirbet Qeiyafa — duplicate candidate | Supported Pass | 6/6 | `artifacts/v0.6.8/fixtures/F11.json` |
| F12 — Memphis/Giza and Pyramid of Khufu — hierarchy | Supported Pass | 6/6 | `artifacts/v0.6.8/fixtures/F12.json` |
| F13 — Batu Caves — unresolved secondaryType review | Supported Pass | 6/6 | `artifacts/v0.6.8/fixtures/F13.json` |
| F14 — Aflaj Irrigation Systems — namespace boundary | Supported Pass | 7/7 | `artifacts/v0.6.8/fixtures/F14.json` |
| F15 — Nuraghe Losa — form versus function | Supported Pass | 7/7 | `artifacts/v0.6.8/fixtures/F15.json` |

## Explicit governance guarantees

- F11 executes a possibly-same-as operation and proves both candidate records and stable IDs remain separate.
- F12 adds hierarchy/component data and compares both parent and child `canonicalType` before and after.
- F13 preserves `secondaryType`, adds an unresolved review flag, and reports that its disposition is unresolved. It does not presuppose retirement.
- Unknown and deprecated controlled values are preserved with warnings; no namespace substitution occurs.
- Restricted and non-point geometries produce explicit projection-loss notices.

## Advanced Canonical Dimensions JSON editor

Verdict: **Supported Pass**

- PASS — Every invalid Advanced JSON case is rejected for the expected reason
- PASS — Validation does not mutate canonical state before Apply
- PASS — Apply produces one before/after transaction
- PASS — Undo restores the exact prior state
- PASS — Redo restores the exact applied state
- PASS — Unknown controlled value is preserved and warned
- PASS — Unknown field survives Apply and canonical output
- PASS — Incomplete relationship pair is reported
- PASS — Relationship validation does not rewrite scholarly review state
- PASS — Restricted coordinates produce an explicit loss notice
- PASS — Deprecated controlled value survives projection unchanged
- PASS — Deprecated controlled value is surfaced for explicit review

Rejected inputs:

- PASS — Malformed JSON: MALFORMED_JSON
- PASS — Wrong top-level shape: WRONG_TOP_LEVEL_SHAPE
- PASS — Invalid entry shape: INVALID_ENTRY_SHAPE
- PASS — Duplicate stable IDs: DUPLICATE_STABLE_ID
- PASS — Missing chronology reference: MISSING_CHRONOLOGY_REFERENCE
- PASS — Invalid location geometry: INVALID_LOCATION_GEOMETRY

Unknown controlled values are preserved and surfaced as review warnings. Structural errors are rejected before a transaction is created.
