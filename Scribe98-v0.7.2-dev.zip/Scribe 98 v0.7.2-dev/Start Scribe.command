#!/bin/bash
# Double-click this file to launch Scribe 98. Closing this window stops it.
cd "$(dirname "$0")"

PY=python3
command -v "$PY" >/dev/null 2>&1 || PY=python
if ! command -v "$PY" >/dev/null 2>&1; then
  echo "Could not find Python on this computer. Scribe needs Python 3 to run its local server."
  echo "Install it from https://www.python.org/downloads/ and then double-click this file again."
  read -p "Press Enter to close..." _
  exit 1
fi

PORT=8000
while lsof -i :"$PORT" >/dev/null 2>&1; do
  PORT=$((PORT + 1))
done

echo "Starting Scribe 98 at http://localhost:$PORT ..."
"$PY" -m http.server "$PORT" >/dev/null 2>&1 &
SERVER_PID=$!
trap 'kill $SERVER_PID 2>/dev/null' EXIT

sleep 1

if [[ "$OSTYPE" == "darwin"* ]]; then
  open "http://localhost:$PORT"
else
  xdg-open "http://localhost:$PORT" >/dev/null 2>&1 || echo "Open this URL in your browser: http://localhost:$PORT"
fi

echo ""
echo "Scribe 98 is running. Leave this window open while you work."
echo "Close this window (or press Ctrl+C) when you're done to stop it."
echo ""

wait "$SERVER_PID"
