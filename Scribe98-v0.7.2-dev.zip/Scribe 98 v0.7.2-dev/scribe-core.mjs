export const ADVANCED_DIMENSIONS = [
  'names', 'locations', 'chronology', 'phases', 'components', 'relationships',
  'evidence', 'conditionAssessments', 'investigations', 'heritage', 'workflow',
  'provenance', 'dataQuality'
];

export const OBJECT_DIMENSIONS = new Set(['heritage', 'workflow', 'provenance', 'dataQuality']);

export const deepClone = value => structuredClone(value);
export const structuralEqual = (a, b) => JSON.stringify(a) === JSON.stringify(b);

// v0.7.0: great-circle distance in km between two lat/lon points. Used by the Curator stage
// (proposal <-> existing-record proximity matching), Recommended Next (possible-duplicate
// flagging), and the Coordinate Inspector minimap's nearby-markers overlay — one shared,
// tested implementation rather than three copies (app.js already has an equivalent inline
// `hav()` helper for the coordinate-moved-distance readout; that one is untouched/unexported
// since it is not part of the governed-transaction surface this module covers).
export function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371, toRad = Math.PI / 180;
  const dLat = (lat2 - lat1) * toRad, dLon = (lon2 - lon1) * toRad;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * toRad) * Math.cos(lat2 * toRad) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

export function detectDatasetShape(records) {
  return records.some(r => 'n' in r || 'lat' in r || 'canonicalType' in r) ? 'archeomaps' : 'scribe';
}

export function extractRecordArray(json) {
  const records = Array.isArray(json) ? json : (json?.records || json?.sites || json?.data);
  if (!Array.isArray(records)) throw Error('No record array found.');
  return records;
}

export function adaptRecord(source, index = 0, datasetShape = 'archeomaps') {
  const r = deepClone(source);
  const loc = (r.locations || []).find(x => x.preferred) || r.locations?.[0];
  const point = loc?.geometry?.type === 'Point' ? loc.geometry.coordinates : null;
  return {
    ...r,
    id: r.id ?? `SCRIBE-${index + 1}`,
    name: r.name ?? r.n ?? r.title ?? 'Unnamed record',
    latitude: r.latitude ?? r.lat ?? point?.[1] ?? '',
    longitude: r.longitude ?? r.lon ?? point?.[0] ?? '',
    canonicalType: r.canonicalType ?? (datasetShape === 'scribe' ? r.type : '') ?? '',
    alternateNames: r.alternateNames ?? (r.names || []).filter(n => !n.preferred).map(n => n.value || n.name).filter(Boolean),
    cultures: r.cultures ?? (r.culture ? [r.culture] : []),
    politicalEntities: r.politicalEntities ?? [],
    functions: r.functions ?? r.function ?? [],
    tags: r.tags ?? [],
    description: r.description ?? r.text ?? '',
    sources: r.sources ?? (r.source ? [r.source] : []),
    phases: r.phases ?? [],
    chronology: r.chronology ?? [],
    components: r.components ?? [],
    relationships: r.relationships ?? [],
    periodStart: r.periodStart ?? r.year ?? '',
    periodEnd: r.periodEnd ?? r.year ?? '',
    reliability: r.reliability ?? '',
    notes: r.notes ?? '',
    needsResearch: r.needsResearch ?? !!r.workflow?.enrichment?.length,
    coordinateAccess: loc?.access ?? r.coordinateVisibility?.access ?? 'public',
    coordinatePrecision: loc?.precision ?? 'exact'
  };
}

export function canonicalRecord(record) {
  const omit = new Set(['n', 'lat', 'lon', 'type', 'culture', 'function', 'text', 'source', 'year', 'coordinateAccess', 'coordinatePrecision']);
  return Object.fromEntries(Object.entries(record).filter(([key]) => !omit.has(key)).map(([key, value]) => [key, deepClone(value)]));
}

export function compatibilityProjection(source, record, changed = false) {
  if (!changed && source) return deepClone(source);
  const out = {
    ...deepClone(source || {}), id: record.id, n: record.name,
    lat: Number(record.latitude), lon: Number(record.longitude),
    canonicalType: record.canonicalType || null, tags: deepClone(record.tags),
    text: record.description || ''
  };
  if (record.functions.length) out.function = deepClone(record.functions); else delete out.function;
  if (record.cultures.length === 1) out.culture = record.cultures[0];
  else if (record.cultures.length > 1) { out.cultures = deepClone(record.cultures); delete out.culture; }
  for (const key of ['phases', 'chronology', 'components', 'relationships']) {
    if (record[key].length) out[key] = deepClone(record[key]);
  }
  if (record.coordinateAccess !== 'public') {
    const publicPoint = (record.locations || []).find(l => l.access === 'public' && l.geometry?.type === 'Point');
    if (publicPoint) {
      out.lon = publicPoint.geometry.coordinates[0];
      out.lat = publicPoint.geometry.coordinates[1];
    } else {
      delete out.lat;
      delete out.lon;
    }
  }
  return out;
}

export function projectionLosses(record, changed = false) {
  const findings = [];
  if (record.coordinateAccess !== 'public') findings.push(['warning', 'locations', 'Exact coordinates withheld from public projection.']);
  if ((record.locations || []).some(l => l.geometry && l.geometry.type !== 'Point')) findings.push(['warning', 'locations', 'Non-point geometry cannot be represented by legacy lat/lon.']);
  if (record.cultures.length > 1) findings.push(['info', 'cultures', 'Older readers may ignore plural cultures.']);
  if (record.functions.length) findings.push(['info', 'functions', 'Canonical functions project to legacy function.']);
  for (const key of ['chronology', 'relationships', 'components', 'evidence', 'conditionAssessments', 'investigations', 'names']) {
    if ((record[key] || []).length) findings.push(['info', key, `${key} remains in JSON but older views may not display it.`]);
  }
  if (Object.prototype.hasOwnProperty.call(record, 'secondaryType')) findings.push(['warning', 'secondaryType', 'Legacy secondaryType is preserved and requires explicit review; its disposition is unresolved.']);
  if (!changed) findings.push(['none', 'roundTrip', 'No edits: original source object exports unchanged.']);
  return findings;
}

export function structuralDiff(before, after, path = '') {
  if (structuralEqual(before, after)) return [];
  if (before === null || after === null || typeof before !== 'object' || typeof after !== 'object') {
    return [{ path: path || '/', before: deepClone(before), after: deepClone(after) }];
  }
  const keys = [...new Set([...Object.keys(before), ...Object.keys(after)])];
  return keys.flatMap(key => structuralDiff(before[key], after[key], `${path}/${String(key).replaceAll('~', '~0').replaceAll('/', '~1')}`));
}

export function registryMaps(registries) {
  // Same plain-array-vs-wrapped-object ambiguity as controlledValueFinding: check
  // Array.isArray before falling back to `.entries`, which is otherwise shadowed
  // by Array.prototype.entries.
  return Object.fromEntries(Object.entries(registries).map(([name, value]) => [name, new Map((Array.isArray(value) ? value : (value?.entries || [])).map(entry => [entry.id, entry.status || 'active']))]));
}

export function controlledValueFinding(registry, value, label) {
  if (!value) return null;
  // `registry` may be a plain entries array (how src/app.js stores loaded registries)
  // or a wrapped `{ entries: [...] }` object (how the evidence scripts load them).
  // Array.prototype.entries is itself a truthy method, so a naive
  // `registry?.entries || registry` check silently picks that method instead of
  // the array for the plain-array case and crashes below. Check Array-ness first.
  const entries = Array.isArray(registry) ? registry : (registry?.entries || []);
  const state = entries.find(entry => entry.id === value)?.status || (entries.some(entry => entry.id === value) ? 'active' : null);
  if (!state) return ['warning', `${label} “${value}” is unknown and preserved without normalization.`];
  if (state === 'deprecated') return ['warning', `${label} “${value}” is deprecated, preserved unchanged, and needs an explicit decision.`];
  return null;
}

function finding(severity, code, path, message, actual, expected) {
  return { severity, code, path, message, actual: deepClone(actual), expected: deepClone(expected) };
}

function requireObjectEntries(value, field, findings) {
  value.forEach((entry, index) => {
    if (entry === null || Array.isArray(entry) || typeof entry !== 'object') {
      findings.push(finding('error', 'INVALID_ENTRY_SHAPE', `/${field}/${index}`, `${field} entries must be JSON objects.`, entry, 'object'));
    }
  });
}

function checkDuplicateIds(value, field, findings) {
  const seen = new Set();
  value.forEach((entry, index) => {
    if (!entry || typeof entry !== 'object' || !entry.id) return;
    if (seen.has(entry.id)) findings.push(finding('error', 'DUPLICATE_STABLE_ID', `/${field}/${index}/id`, `Duplicate stable ID “${entry.id}”.`, entry.id, 'unique ID'));
    seen.add(entry.id);
  });
}

function checkVocabulary(maps, registryName, value, path, label, findings) {
  if (!value) return;
  const state = maps[registryName]?.get(value);
  if (!state) findings.push(finding('warning', 'UNKNOWN_VOCABULARY_VALUE', path, `${label} “${value}” is unknown and will be preserved without normalization.`, value, 'registered value or reviewed unknown'));
  else if (state === 'deprecated') findings.push(finding('warning', 'DEPRECATED_VOCABULARY_VALUE', path, `${label} “${value}” is deprecated and will be preserved pending explicit review.`, value, 'active value or reviewed deprecated value'));
}

export function validateAdvancedValue(field, value, { registries = {}, record = {} } = {}) {
  if (!ADVANCED_DIMENSIONS.includes(field)) throw Error(`Unsupported advanced dimension: ${field}`);
  const findings = [];
  const expectsObject = OBJECT_DIMENSIONS.has(field);
  if (expectsObject && (value === null || Array.isArray(value) || typeof value !== 'object')) {
    findings.push(finding('error', 'WRONG_TOP_LEVEL_SHAPE', `/${field}`, `${field} must be a JSON object.`, value, 'object'));
    return findings;
  }
  if (!expectsObject && !Array.isArray(value)) {
    findings.push(finding('error', 'WRONG_TOP_LEVEL_SHAPE', `/${field}`, `${field} must be a JSON array.`, value, 'array'));
    return findings;
  }
  if (expectsObject) return findings;

  requireObjectEntries(value, field, findings);
  checkDuplicateIds(value, field, findings);
  const maps = registryMaps(registries);
  const chronologyIds = new Set(field === 'chronology' ? value.map(x => x?.id).filter(Boolean) : (record.chronology || []).map(x => x.id).filter(Boolean));
  value.forEach((entry, index) => {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return;
    if (field === 'phases') checkVocabulary(maps, 'phase-types', entry.type, `/${field}/${index}/type`, 'Phase type', findings);
    if (field === 'relationships') checkVocabulary(maps, 'relationship-types', entry.relationshipType, `/${field}/${index}/relationshipType`, 'Relationship type', findings);
    if (field === 'evidence') checkVocabulary(maps, 'evidence-forms', entry.form || entry.evidenceForm, `/${field}/${index}/form`, 'Evidence form', findings);
    if (field === 'conditionAssessments') checkVocabulary(maps, 'conditions', entry.condition, `/${field}/${index}/condition`, 'Condition', findings);
    if (field === 'investigations') checkVocabulary(maps, 'investigation-types', entry.type, `/${field}/${index}/type`, 'Investigation type', findings);
    if (field === 'locations') {
      checkVocabulary(maps, 'location-types', entry.type, `/${field}/${index}/type`, 'Location type', findings);
      checkVocabulary(maps, 'location-access', entry.access, `/${field}/${index}/access`, 'Location access', findings);
      checkVocabulary(maps, 'location-precision', entry.precision, `/${field}/${index}/precision`, 'Location precision', findings);
      if (!entry.geometry || typeof entry.geometry !== 'object' || !entry.geometry.type || !Array.isArray(entry.geometry.coordinates)) {
        findings.push(finding('error', 'INVALID_LOCATION_GEOMETRY', `/${field}/${index}/geometry`, 'Location geometry must contain a GeoJSON type and coordinates array.', entry.geometry, '{ type, coordinates[] }'));
      }
    }
    if (field === 'chronology' && !entry.id) findings.push(finding('error', 'MISSING_STABLE_ID', `/${field}/${index}/id`, 'Chronology assertions require a stable ID.', entry.id, 'non-empty ID'));
    if (field === 'relationships' && !entry.targetSiteId) findings.push(finding('error', 'MISSING_RELATIONSHIP_TARGET', `/${field}/${index}/targetSiteId`, 'Relationships require targetSiteId.', entry.targetSiteId, 'non-empty site ID'));
    if (field === 'phases' || field === 'components') {
      for (const [refIndex, id] of (entry.chronologyIds || []).entries()) {
        if (!chronologyIds.has(id)) findings.push(finding('error', 'MISSING_CHRONOLOGY_REFERENCE', `/${field}/${index}/chronologyIds/${refIndex}`, `Reference “${id}” does not identify a chronology assertion on this record.`, id, [...chronologyIds]));
      }
    }
  });
  return findings;
}

export function parseAdvancedDocument(field, text, context = {}) {
  let value;
  try { value = JSON.parse(text); }
  catch (error) {
    const wrapped = Error(`Malformed JSON: ${error.message}`);
    wrapped.findings = [finding('error', 'MALFORMED_JSON', `/${field}`, wrapped.message, text, 'valid JSON')];
    throw wrapped;
  }
  const findings = validateAdvancedValue(field, value, context);
  const errors = findings.filter(item => item.severity === 'error');
  if (errors.length) {
    const wrapped = Error(errors.map(item => item.message).join(' '));
    wrapped.findings = findings;
    throw wrapped;
  }
  return { value: deepClone(value), findings };
}

export function stageAdvancedTransaction(record, field, text, context = {}) {
  const before = deepClone(record);
  const parsed = parseAdvancedDocument(field, text, { ...context, record: before });
  const after = deepClone(before);
  after[field] = deepClone(parsed.value);
  return { field, before, after, findings: parsed.findings };
}

export function stageRecordReplacement(record, replacement) {
  return { before: deepClone(record), after: deepClone(replacement) };
}

export function undoTransaction(transaction) { return deepClone(transaction.before); }
export function redoTransaction(transaction) { return deepClone(transaction.after); }

export function validateCanonicalLinks(record) {
  const findings = [];
  const ids = new Set((record.chronology || []).map(item => item.id));
  for (const phase of record.phases || []) {
    if (!phase.type) findings.push(['warning', `Phase ${phase.id || phase.label} has no phase type.`]);
    for (const id of phase.chronologyIds || []) if (!ids.has(id)) findings.push(['error', `Phase ${phase.id || phase.label} links to missing chronology ${id}.`]);
  }
  for (const component of record.components || []) {
    if (!component.label) findings.push(['error', `Component ${component.id || 'entry'} has no label.`]);
    for (const id of component.chronologyIds || []) if (!ids.has(id)) findings.push(['error', `Component ${component.id || component.label} links to missing chronology ${id}.`]);
  }
  return findings;
}

export const reciprocalRelationship = type => ({
  'part-of': 'has-part', 'has-part': 'part-of',
  'component-of': 'has-component', 'has-component': 'component-of',
  'preceded-by': 'succeeded-by', 'succeeded-by': 'preceded-by',
  'same-as': 'same-as', 'possibly-same-as': 'possibly-same-as'
}[type] || type);

export function validateRelationships(record, records) {
  const findings = [];
  for (const relationship of record.relationships || []) {
    if (!relationship.targetSiteId) {
      findings.push(['error', 'Relationship has no targetSiteId.']);
      continue;
    }
    const target = records.find(candidate => candidate.id === relationship.targetSiteId);
    if (!target) findings.push(['warning', `Target ${relationship.targetSiteId} is outside the loaded set.`]);
    if (relationship.pairId) {
      const reciprocal = target?.relationships?.some(back => back.targetSiteId === record.id && back.pairId === relationship.pairId && back.relationshipType === reciprocalRelationship(relationship.relationshipType));
      if (!reciprocal) findings.push(['warning', `Pair ${relationship.pairId} is incomplete or contradictory; review state remains unchanged.`]);
    }
  }
  return findings;
}
