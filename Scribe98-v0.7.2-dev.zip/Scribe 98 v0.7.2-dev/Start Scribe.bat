@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

where python >nul 2>&1
if errorlevel 1 (
    where python3 >nul 2>&1
    if errorlevel 1 (
        echo Could not find Python on this computer. Scribe needs Python 3 to run its local server.
        echo Install it from https://www.python.org/downloads/ and then double-click this file again.
        pause
        exit /b 1
    ) else (
        set PY=python3
    )
) else (
    set PY=python
)

set PORT=8000
:checkport
netstat -ano | findstr :%PORT% | findstr LISTENING >nul
if not errorlevel 1 (
    set /a PORT+=1
    goto checkport
)

echo Starting Scribe 98 at http://localhost:%PORT% ...
start "Scribe98Server" /min cmd /c "%PY% -m http.server %PORT%"

timeout /t 1 /nobreak >nul
start "" "http://localhost:%PORT%"

echo.
echo Scribe 98 is running in the "Scribe98Server" window.
echo Close that window when you're done to stop it.
echo.
pause >nul
